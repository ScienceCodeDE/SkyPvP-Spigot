package de.gomme.skypvp.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;

public class Fly implements CommandExecutor {

	@Override
	  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
	  {
	    Player p = (Player)sender;
	    if (cmd.getName().equalsIgnoreCase("fly")) {
	      if ((sender instanceof Player))
	      {
	        if (args.length == 0) {
	          if (p.hasPermission("skypvp.fly"))
	          {
	            if (p.getAllowFlight())
	            {
	              p.setAllowFlight(false);
	              p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu kannst nun nicht mehr fliegen!");
	            }
	            else
	            {
	              p.setAllowFlight(true);
	              p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu kannst nun fliegen!");
	            }
	          }
	          else {
	              sender.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
	          }
	        }
	        if (args.length == 1) {
	          if (p.hasPermission("skypvp.fly.other")) {
	            try
	            {
	              Player target = p.getServer().getPlayer(args[0]);
	              if (target.getAllowFlight())
	              {
	                target.setAllowFlight(false);
	                target.sendMessage(Main.instance.cfg.getString("Prefix") + "�eDu kannst nun nicht mehr fliegen!");
	                p.sendMessage("�aDer Spieler �e" + args[0] + " �akann nun nicht mehr fliegen!");
	              }
	              else
	              {
	                target.setAllowFlight(true);
	                target.sendMessage(Main.instance.cfg.getString("Prefix") + "�eDu kannst nun fliegen!");
	                p.sendMessage("�aDer Spieler �e" + args[0] + " �akann nun fliegen!");
	              }
	            }
	            catch (NullPointerException a)
	            {
	              sender.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDer Spieler �4" + args[0] + " �cist nicht Online!");
	            }
	          } else {
	              sender.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
	          }
	        }
	      }
	      else
	      {
	    	  sender.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDu musst ein Spieler sein um dies ausf�hren zu k�nnen!");
	      }
	    }
	    return false;
	  }
	}

