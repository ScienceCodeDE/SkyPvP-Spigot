package de.gomme.skypvp.commands;

import de.gomme.skypvp.main.Main;
import de.gomme.skypvp.utils.UmfrageManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DeleteUmfrage
  implements CommandExecutor
{
  public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args)
  {
    Player player = (Player)sender;
    if (player.hasPermission("skypvp.umfrage"))
    {
      if (UmfrageManager.runsUmfrage())
      {
        if (args.length == 0)
        {
          for (Player online : Bukkit.getOnlinePlayers())
          {
            online.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDie Umfrage �e" + UmfrageManager.getCurrentUmfrage() + "�a hat ergeben�e:");
            online.sendMessage(Main.instance.cfg.getString("Prefix") + "�8� �aJa: �e" + UmfrageManager.getYes());
            online.sendMessage(Main.instance.cfg.getString("Prefix") + "�8� �aNein: �c" + UmfrageManager.getNo());
            online.sendMessage(Main.instance.cfg.getString("Prefix") + "�8� �aTeilnehmer: �a" + UmfrageManager.getVotes());
          }
          UmfrageManager.deleteUmfrage();
        }
        else
        {
          player.sendMessage(Main.instance.cfg.getString("Prefix") + "�c/createumfrage [Frage]");
        }
      }
      else {
        player.sendMessage(Main.instance.cfg.getString("Prefix") + "�cEs l�uft keine Umfrage!");
      }
    }
    else {
      player.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
    }
    return false;
  }
}
