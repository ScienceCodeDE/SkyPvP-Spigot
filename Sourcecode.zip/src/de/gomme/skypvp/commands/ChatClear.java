package de.gomme.skypvp.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;

public class ChatClear implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player p = (Player) sender;
		if (p.hasPermission("skypvp.cc")) {
			if (sender instanceof Player && args.length == 0) {
				for (int i = 0; i < 150; i++) {
					Bukkit.broadcastMessage("");
				}

				if (p.hasPermission("skypvp.cc")) {
					Bukkit.broadcastMessage(Main.instance.cfg.getString("Prefix") + Main.instance.cfg.getString("ChatClear").replaceAll("%player%", p.getName()).replaceAll("&", "�"));
					return true;
				}
			}
		} else {
			p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");

		}
		return false;

	}
}
