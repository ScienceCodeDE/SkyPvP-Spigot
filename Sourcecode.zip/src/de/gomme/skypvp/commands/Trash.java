package de.gomme.skypvp.commands;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import de.gomme.skypvp.main.Main;

public class Trash implements CommandExecutor {
		
	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		
		if(sender instanceof Player) {
			Player p = (Player) sender;
			if(p.hasPermission("skypvp.spieler")) {
				if(args.length == 0) {
					
					Inventory inv = Bukkit.createInventory(null, 9 * 3, "�c�lM�lleimer");
					
					ItemStack item = new ItemStack(Material.PAPER);
					ItemMeta imeta = item.getItemMeta();
					imeta.setDisplayName("�6�l-> M�lleimer");
					imeta.addEnchant(Enchantment.DAMAGE_ALL, -1, false);
					item.setItemMeta(imeta);
					item.setAmount(1);
					
					inv.addItem(item);
					p.openInventory(inv);
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast das M�ll-Inventar erfolgreich ge�ffnet!");
					
				} else
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cBitte benutze /m�ll!");
				
			} else
				p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
		}
		return false;
	}
	

}
