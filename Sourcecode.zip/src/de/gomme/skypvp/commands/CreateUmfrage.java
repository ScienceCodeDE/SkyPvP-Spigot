package de.gomme.skypvp.commands;

import de.gomme.skypvp.main.Main;
import de.gomme.skypvp.utils.UmfrageManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CreateUmfrage
  implements CommandExecutor
{
  public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args)
  {
    Player player = (Player)sender;
    if (player.hasPermission("skypvp.umfrage"))
    {
      if (!UmfrageManager.runsUmfrage())
      {
        if (args.length >= 1)
        {
          String umfrage = "";
          for (int i = 0; i < args.length; i++) {
            umfrage = umfrage + args[i] + " ";
          }
          UmfrageManager.createUmfrage(umfrage);
          for (Player online : Bukkit.getOnlinePlayers())
          {
        	online.sendMessage("                      ");
            online.sendMessage(Main.instance.cfg.getString("Prefix") + Main.instance.cfg.getString("Umfrage.1").replaceAll("&", "�").replaceAll("%umfrage%", umfrage));
            online.sendMessage(Main.instance.cfg.getString("Prefix") + Main.instance.cfg.getString("Umfrage.2").replaceAll("&", "�").replaceAll("%umfrage%", umfrage));
            online.sendMessage(Main.instance.cfg.getString("Prefix") + Main.instance.cfg.getString("Umfrage.3").replaceAll("&", "�").replaceAll("%umfrage%", umfrage));
        	online.sendMessage("                      ");

          }
        }
        else
        {
          player.sendMessage(Main.instance.cfg.getString("Prefix") + "�cSyntax: /createumfrage [Frage]");
        }
      }
      else {
        player.sendMessage(Main.instance.cfg.getString("Prefix") + Main.instance.cfg.getString("Umfrage.Already").replaceAll("&", "�"));
      }
    }
    else {
      player.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
    }
    return false;
  }
}
