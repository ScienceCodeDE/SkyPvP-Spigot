package de.gomme.skypvp.commands;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import de.gomme.skypvp.main.Main;

public class Troll implements CommandExecutor {

	int cd = 50;

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		Player p = (Player) sender;
		if (args.length == 0) {
			if (p.hasPermission("skypvp.troll")) {
				p.sendMessage("                     ");
				p.sendMessage("�e-=-=-=- �6Troll System �e-=-=-=-");
				p.sendMessage("            ");
				p.sendMessage("�6-> �a/troll �7- �eZeigt diese Hilfe");
				p.sendMessage("�6-> �a/troll gm �7- �eVersetzt dich in den GameMode 1");
				p.sendMessage("�6-> �a/troll vanish �7- �eGehe in den Vanish Modus");
				p.sendMessage("�6-> �a/troll fire �7- �eGibt dir einen Flammenbogen");
				p.sendMessage("�6-> �a/troll hacked �7- �eT�uscht einen Server-Hack");
				p.sendMessage("�6-> �a/troll accounthacked �7- �eT�uscht einen Account Hack an.");
				p.sendMessage("�6-> �a/troll reload �7- �eReloade das TrollSystem falls Bugs auftreten");
				p.sendMessage("            ");

			} else
				p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");

		} else if (args[0].equalsIgnoreCase("gm")) {
			p.performCommand("gm 1");

		} else if (args[0].equalsIgnoreCase("vanish")) {
			p.performCommand("vanish");

		} else if (args[0].equalsIgnoreCase("fire")) {
			{
				ItemStack pfeil = new ItemStack(Material.ARROW, 1);
				ItemStack bow = new ItemStack(Material.BOW);
				ItemMeta mbow = bow.getItemMeta();
				mbow.setDisplayName("�eFeuer-Bogen");
				bow.setItemMeta(mbow);
				bow.addEnchantment(Enchantment.ARROW_FIRE, 1);
				bow.addEnchantment(Enchantment.ARROW_INFINITE, 1);
				p.getInventory().addItem(new ItemStack[] { bow });
				p.getInventory().addItem(new ItemStack[] { pfeil });
				p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast erfolgreich den �eFeuer-Bogen �aerhalten!");
			}
		} else if (args[0].equalsIgnoreCase("hacked")) {
			Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.getPlugin(Main.class), new Runnable() {
				public void run() {
					Troll.this.cd -= 1;
					Bukkit.broadcastMessage("�c�ksnhcbnswcdbwudzbsucdh");
					if (Troll.this.cd == 0) {
						Bukkit.broadcastMessage("�c�ksnhcbnswcdbwudzbsucdh");

						Bukkit.getScheduler().cancelAllTasks();
						Bukkit.reload();
					}
				}
			}, 0L, 20L);
		} else if (args[0].equalsIgnoreCase("reload")) {
			p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aEs sollte nun wieder alles einwandfrei gehen!");
			Bukkit.reload();
		} else if (args[0].equalsIgnoreCase("accounthacked")) {

			for (Player all : Bukkit.getOnlinePlayers()) {
				
				all.sendMessage(Main.instance.cfg.getString("Prefix") + "�cAchtung: Unser System hat entdeckt das Sie hacken!");
				all.sendMessage(Main.instance.cfg.getString("Prefix") + "�cSomit wurde Ihr Account Passwort + Benutzer ge�ndert!");
				all.sendMessage(Main.instance.cfg.getString("Prefix") + "�cSupport unter: https://help.mojang.com/");
				
			}

		}

		return false;

	}
}
