package de.gomme.skypvp.commands;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;

public class Vanish implements CommandExecutor {

	ArrayList<String> vanish = new ArrayList<String>();
	public static ArrayList<Player> players = new ArrayList<>();

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player p = (Player) sender;

		if (p.hasPermission("skypvp.vanish")) {
			if (args.length == 0) {
				if (vanish.contains(p.getName())) {
					vanish.remove(p.getName());
					for (Player all : Bukkit.getOnlinePlayers()) {
						all.showPlayer(p);
						players.remove(p);
						p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu bist nun nicht mehr im Vanish");
					}
				} else {
					for (Player all : Bukkit.getOnlinePlayers()) {
						all.hidePlayer(p);
					}
					vanish.add(p.getName());
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu bist nun im Vanish");
					players.add(p);

				}
			} else if (args.length == 1) {

			} else {
				p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cSyntax: /vanish");
			}
		} else {
			p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte");
		}
		return false;
	}
}