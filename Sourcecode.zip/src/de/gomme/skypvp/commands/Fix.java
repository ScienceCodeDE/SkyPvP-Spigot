package de.gomme.skypvp.commands;

import de.gomme.skypvp.main.Main;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Fix
  implements CommandExecutor
{
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    Player p = (Player)sender;
    if (cmd.getName().equalsIgnoreCase("fix"))
    {
      Location loc = p.getLocation();
      loc.add(0.0D, 1.0D, 0.0D);
      
      p.teleport(loc);
      p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu wurdest erfolgreich gefixt!");
    }
    return false;
  }
}
