package de.gomme.skypvp.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerKickEvent;

import de.gomme.skypvp.main.Main;
import de.gomme.skypvp.utils.Stats;

public class Kill implements CommandExecutor, Listener {

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		
		if (sender instanceof Player) {
			Player p = (Player) sender;
			Stats stats = new Stats(p);
			if (args.length == 0) {
				if (p.hasPermission("skypvp.kill.self") || p.hasPermission("skypvp.kill.*")) {
					p.setHealth(0);
					p.spigot().respawn();
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast dich erfolgreich get�tet!");
				} else
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");

			} else if (args.length == 1) {
				Player target = Bukkit.getPlayer(args[0]);
				if (target != null) {
					if (p.hasPermission("skypvp.kill.others") || p.hasPermission("skypvp.kill.*")) {
						target.setHealth(0);
						target.spigot().respawn();
						p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast �c" + target.getDisplayName() + " �aerfolgreich get�tet!");
					} else
						p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");

				} else {
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDer angegebene Spieler ist nicht Online!");
				}

			} else {
				p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cBitte benutze /kill <Spieler>");
			}
		}
		return false;

	}

	
	@EventHandler
	public void killEvent(PlayerDeathEvent e) {
		e.setDeathMessage(" ");
	}

}

