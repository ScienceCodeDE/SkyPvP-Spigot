package de.gomme.skypvp.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;

public class DropEvent implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

		if (sender instanceof Player) {
			Player p = (Player) sender;
			if (args.length == 0) {
				if (p.hasPermission("skypvp.dropevent")) {
					p.sendMessage("                          ");
					Bukkit.broadcastMessage(Main.instance.cfg.getString("Prefix") + "�cAchtung: �aIn K�rze findet ein DropEvent statt. \n �7[�eDropEvent von �c" + p.getName() + "�7]");
					p.sendMessage("                          ");
				} else
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
			}
		}
		return false;
	}
}
