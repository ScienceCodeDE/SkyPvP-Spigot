package de.gomme.skypvp.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import de.gomme.skypvp.main.Main;

public class KickAll implements CommandExecutor, Listener {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		Player p = (Player) sender;
		if (p.hasPermission("skypvp.kickall")) {
			if (args.length == 0) {
				for (Player all : Bukkit.getServer().getOnlinePlayers()) {
					if(!all.hasPermission("skypvp.bypass")) {
						all.kickPlayer(Main.instance.cfg.getString("Prefix") + "�cDu wurdest vom Server gekickt! \n\n �cGrund: �eKickAll");
					} else if (p.hasPermission("skypvp.bypass")){
						all.sendMessage(Main.instance.cfg.getString("Prefix") + "�aEs hat ein StartKick stattgefunden, jedoch wurdest du nicht gekickt weil du die Permission hast!");
					} else {
						p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cSyntax: /kickall");
					}
				}
			}

		}
		return false;

	}
}
