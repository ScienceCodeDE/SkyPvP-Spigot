package de.gomme.skypvp.commands;

import de.gomme.skypvp.main.Main;
import de.gomme.skypvp.utils.UmfrageManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Umfrage
  implements CommandExecutor
{
  public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args)
  {
    Player player = (Player)sender;
    if (player.hasPermission("skypvp.vote"))
    {
      if (UmfrageManager.runsUmfrage())
      {
        if (args.length == 1)
        {
          if (args[0].equalsIgnoreCase("info"))
          {
            player.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu kannst f�r die Umfrage" + 
              UmfrageManager.getCurrentUmfrage() + "�a mit �e:");
            player.sendMessage(Main.instance.cfg.getString("Prefix") + "�8� �aVote f�r Ja: �e/umfrage ja");
            player.sendMessage(Main.instance.cfg.getString("Prefix") + "�8� �aVote f�r Nein: �e/umfrage nein");
            player.sendMessage(Main.instance.cfg.getString("Prefix") + "�8� �aDerzeitige Teilnehmer: �e" + UmfrageManager.getVotes());
            player.sendMessage(Main.instance.cfg.getString("Prefix") + "�7... abstimmen.");
          }
          else if (args[0].equalsIgnoreCase("ja"))
          {
            if (!UmfrageManager.hasVoted(player.getUniqueId().toString()))
            {
              UmfrageManager.voteYes(player.getUniqueId().toString());
              player.sendMessage(Main.instance.cfg.getString("Prefix") + "�a Du hast f�r �cJa �aabgestimmt.");
              player.sendMessage(Main.instance.cfg.getString("Prefix") + "�7Du bist der �e" + UmfrageManager.getVotes() + ". �a7Teilnehmer");
            }
            else
            {
              player.sendMessage(Main.instance.cfg.getString("Prefix") + "Du hast schon abgestimmt");
            }
          }
          else if (args[0].equalsIgnoreCase("nein"))
          {
            if (!UmfrageManager.hasVoted(player.getUniqueId().toString()))
            {
              UmfrageManager.voteNo(player.getUniqueId().toString());
              player.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast f�r �cNein �aabgestimmt.");
              player.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu bist der �e" + UmfrageManager.getVotes() + 
                ". �aTeilnehmer");
            }
            else
            {
              player.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDu hast bereits abgestimmt!");
            }
          }
          else
          {
            player.sendMessage(Main.instance.cfg.getString("Prefix") + "�a/umfrage info");
            player.sendMessage(Main.instance.cfg.getString("Prefix") + "�a/umfrage ja/nein");
          }
        }
        else
        {
          player.sendMessage(Main.instance.cfg.getString("Prefix") + "�a/umfrage info");
          player.sendMessage(Main.instance.cfg.getString("Prefix") + "�a/umfrage ja/nein");
        }
      }
      else {
        player.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDerzeit findet keine Umfrage statt!");
      }
    }
    else {
      player.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte");
    }
    return false;
  }
}
