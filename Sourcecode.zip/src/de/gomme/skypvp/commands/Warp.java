package de.gomme.skypvp.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;

public class Warp implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		if (args.length == 0) {
			
			Player p = (Player)sender;
			p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cSyntax: /warp [Spawn");
			
			if (args[0].equalsIgnoreCase("spawn")) {
				
				p.performCommand("spawn");
				
			} else if (args[0].equalsIgnoreCase("gui")) {

			}
			
		}
		
		return false;
	}
	
	

}
