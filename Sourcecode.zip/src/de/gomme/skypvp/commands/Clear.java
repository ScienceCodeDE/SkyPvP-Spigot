package de.gomme.skypvp.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;

public class Clear implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		Player p = (Player)sender;
		
		if(cmd.getName().equalsIgnoreCase("clear")) {
			p.sendMessage(Main.instance.cfg.getString("Prefix") + Main.instance.cfg.getString("Clear").replaceAll("&", "�"));
			p.getInventory().clear();
			clearArmor(p);
			}
		return false;
		

	}
	  private void clearArmor(Player player)
	  {
	    player.getInventory().setHelmet(null);
	    player.getInventory().setChestplate(null);
	    player.getInventory().setLeggings(null);
	    player.getInventory().setBoots(null);
	  }
	
}
