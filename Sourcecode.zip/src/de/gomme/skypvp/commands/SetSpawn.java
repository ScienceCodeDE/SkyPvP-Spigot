package de.gomme.skypvp.commands;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;

public class SetSpawn implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

		Player p = (Player) sender;
        if(label.equalsIgnoreCase("spawn")) {
            if(!p.hasPermission("skypvp.spieler")) {
            	p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
                return true;
            }
            p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu wurdest zum �eSpawn �ateleportiert!");
            p.teleport(p.getWorld().getSpawnLocation());
        }
 
        if(label.equalsIgnoreCase("setspawn")) {
            if(!p.hasPermission("skypvp.admin")) {
            	p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
                return true;
            }
                    World world = p.getWorld();
                    Location loc = p.getLocation();
                    p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast erfolgreich den Spawn gesetzt!");
                    world.setSpawnLocation(loc.getBlockX(), loc.getBlockY() + 1, loc.getBlockZ());
                    
        }
		return false;
        	
        }
}
