package de.gomme.skypvp.commands;

import java.util.ArrayList;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

import de.gomme.skypvp.main.Main;;

public class Build
  implements CommandExecutor, Listener
{
  public static ArrayList<Player> build = new ArrayList();
  
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    Player p = (Player)sender;
    if (cmd.getName().equalsIgnoreCase("build"))
    {
      if (p.hasPermission("build.use"))
      {
        if (build.contains(p))
        {
          build.remove(p);
          p.sendMessage(Main.instance.cfg.getString("Prefix") + Main.instance.cfg.getString("Build.Off").replaceAll("%player%", p.getName()).replaceAll("&", "§"));
          p.setGameMode(GameMode.SURVIVAL);
        }
        else if (!build.contains(p))
        {
          build.add(p);
          p.sendMessage(Main.instance.cfg.getString("Prefix") + Main.instance.cfg.getString("Build.On").replaceAll("%player%", p.getName()).replaceAll("&", "§"));
          p.setGameMode(GameMode.CREATIVE);
        }
      }
      else {
        p.sendMessage(Main.instance.cfg.getString("Prefix") + "§cDazu hast du keine Rechte!!");
      }
    }
    else {
      p.sendMessage(Main.instance.cfg.getString("Prefix") + Main.instance.cfg.getString("Build.Syntax").replaceAll("&", "§"));
    }
    return true;
  }
  
  @EventHandler
  public void onBreak(BlockBreakEvent e)
  {
    Player p = e.getPlayer();
    if (build.contains(p)) {
      e.setCancelled(true);
    } else if (!build.contains(p)) {
      e.setCancelled(false);
    }
  }
}
