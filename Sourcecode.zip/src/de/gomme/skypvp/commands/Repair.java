package de.gomme.skypvp.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import de.gomme.skypvp.main.Main;

public class Repair
  implements CommandExecutor
{
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
  {
    if ((sender instanceof Player))
    {
      Player p = (Player)sender;
      if (label.equalsIgnoreCase("repair")) {
        if (p.hasPermission("skypvp.use"))
        {
          if (args.length == 0)
          {
            double durability = p.getItemInHand().getDurability();
            if (durability == 1.0D)
            {
            	p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDu hast kein Gegenstand in der Hand was repariert werden kann!");
            }
            else if (durability == 0.0D)
            {
            	p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDieser Gegenstand kann nicht repariert werden!");
            }
            else if (p.getItemInHand() == null) {
            	p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDieser Gegenstand ist kein Item.");
            }
            else
            {
              p.getItemInHand().setDurability((short)0);
              p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast erfolgreich das Item repariert!");
            }
          }
          else
          {
        	  p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cBitte benutze /repair");
          }
        }
        else {
        	p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
        }
      }
    }
    else
    {
    	sender.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDieser Command ist nur In-Game m�glich!");
    }
    return true;
  }
}
