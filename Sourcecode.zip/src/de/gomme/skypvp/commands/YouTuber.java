package de.gomme.skypvp.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class YouTuber implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		Player p = (Player)sender;
		
			p.sendMessage("                     ");
			p.sendMessage("�e-=-=-=- �5�lYouTuber �r�e-=-=-=-");
			p.sendMessage("                     ");
			p.sendMessage("�a+ �eMind. 150 Abos");
			p.sendMessage("�a+ �eAngemessene Klickzahl");
			p.sendMessage("�a+ �eMind. 1 Servervorstellung");
			p.sendMessage("�a+ �ePositives Erscheinungsbild");
			p.sendMessage("                     ");
			p.sendMessage("�e-=-=-=- �5�lYouTuber �r�e-=-=-=-");
			p.sendMessage("                     ");


		return false;
		
	}
	
}
