package de.gomme.skypvp.commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import de.gomme.skypvp.main.Main;

public class GiveAll implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if(command.getName().equalsIgnoreCase("giveall")){

            if(sender instanceof Player){

                Player p = (Player) sender;

                if(p.hasPermission("skypvp.giveall")){

                    if(args.length == 0) {

                        ItemStack item = p.getItemInHand();
                        String amount = String.valueOf(item.getAmount());
                        String itemName = item.getItemMeta().getDisplayName();
                        String itemType = item.getType().name();

                        for (Player online : Bukkit.getOnlinePlayers()) {

                            online.getInventory().addItem(item);


                        }
                        if(itemName != null) {
                            Bukkit.broadcastMessage(Main.instance.cfg.getString("Prefix") + "�aDer Spieler �e" + p.getName() + " �ahat jedem Spieler �c\n" + amount + " �c" + itemType + " �agegeben");
                        }

                        else{

                            Bukkit.broadcastMessage(Main.instance.cfg.getString("Prefix") + "�aDer Spieler �e" + p.getName() + " �ahat jedem Spieler �c\n" + amount + " �c" + itemType + " �agegeben");
                        }


                        return true;

                    }

                    if(args.length == 1){

                        int radius;

                        try{

                            radius = Integer.parseInt(args[0]);

                        }catch(NumberFormatException e){

                            p.sendMessage(Main.instance.cfg.getString("Prefix") + "�4Du musst eine g�ltige Nummer angeben!");
                            return true;

                        }
                        ItemStack item = p.getItemInHand();
                        String amount = String.valueOf(item.getAmount());
                        String itemName = item.getItemMeta().getDisplayName();
                        String itemType = item.getType().name();

                        for(Entity entity : p.getNearbyEntities(radius, radius, radius)){

                            if(entity instanceof Player){

                                if(itemName != null) {
                                    Bukkit.broadcastMessage(Main.instance.cfg.getString("Prefix") + "�aDer Spieler �e" + p.getName() + " �ahat jedem Spieler �c " + amount + " �c " + itemType + " gegeben");
                                }

                                else{
                                    Bukkit.broadcastMessage(Main.instance.cfg.getString("Prefix") + "�aDer Spieler �e" + p.getName() + " �ahat jedem Spieler �c " + amount + " �c " + itemType + " gegeben");
                                }


                                ((Player) entity).getInventory().addItem(item);

                            }

                        }



                    }


                }else{

                    p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
                    return true;

                }

            }else{

                sender.sendMessage(Main.instance.cfg.getString("Prefix") + "Du musst ein Spieler sein um dies zu benutzen!");
                return true;

            }

        }

        return false;
    }
}