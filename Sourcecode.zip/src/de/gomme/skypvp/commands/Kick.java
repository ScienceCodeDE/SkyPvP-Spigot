package de.gomme.skypvp.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;

public class Kick implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

		if (sender instanceof Player) {
			Player p = (Player) sender;
			if (args.length == 0) {
				if (p.hasPermission("skypvp.kick")) {
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cSyntax: /kick [Name]");
				} else
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");

			} else if (args.length == 1) {
				Player target = Bukkit.getPlayer(args[0]);
				if (target != null) {
					if (p.hasPermission("skypvp.kick")) {
						target.kickPlayer(Main.instance.cfg.getString("Prefix") + "�cDu wurdest vom Server gekickt! \n �aDu wurdest zu unrecht gekickt? Melde dich im TS \n\n\n �eDu wurdest gekickt von �a " + p.getName());
					} else
						p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");

				} else {
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDer angegebene Spieler ist nicht Online!");
				}

			} else {
				p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cBitte benutze /kick <Spieler>");
			}
		}
		return false;

	}

}
