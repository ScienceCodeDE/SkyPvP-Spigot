package de.gomme.skypvp.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;

public class Website implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		Player p = (Player)sender;
		
			p.sendMessage("                     ");
			p.sendMessage("�e-=-=-=- �b�lWebseite �r�e-=-=-=-");
			p.sendMessage("                     ");
			p.sendMessage("�a-=- " + Main.instance.cfg.getString("Links.Website").replaceAll("&", "�") +  " �a-=-");
			p.sendMessage("                     ");
			p.sendMessage("�e-=-=-=- �b�lWebseite �r�e-=-=-=-");
			p.sendMessage("                     ");


		return false;
		
	}
	
}
