package de.gomme.skypvp.commands;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import de.gomme.skypvp.main.Main;

public class Head
  implements CommandExecutor
{
  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args)
  {
    Player p = (Player)sender;
    if (!p.hasPermission("skypvp.head"))
    {
      p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
      return true;
    }
    if (args.length == 1)
    {
      ItemStack is = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
      SkullMeta im = (SkullMeta)is.getItemMeta();
      im.setOwner(args[0]);
      im.setDisplayName(args[0]);
      p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast den Kopf von �e" + im.getDisplayName() + "�a erhalten!");
      is.setItemMeta(im);
      p.getInventory().addItem(new ItemStack[] { is });
      p.updateInventory();
      return true;
    }
    p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cSyntax: /kopf [Spieler]");
    
    return false;
  }
}
