package de.gomme.skypvp.commands;

import java.util.Random;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import de.gomme.skypvp.main.Main;

public class Verlosung implements CommandExecutor {
	int cd = 5;

	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player p = (Player) sender;
		if(args.length == 0) {
			p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
		}
		if (args.length == 1) {
			if (p.hasPermission("skypvp.rang")) {
				Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.getPlugin(Main.class), new Runnable() {
					public void run() {
						Verlosung.this.cd -= 1;
						Bukkit.broadcastMessage("                  ");
						Bukkit.broadcastMessage(Main.instance.cfg.getString("Prefix") + "�aDer �e" + args[0] + " �aRang wird in �c" + Verlosung.this.cd+ " �aSekunden verlost!");
						Bukkit.broadcastMessage("                  ");
						if (Verlosung.this.cd == 0) {
							Bukkit.getScheduler().cancelAllTasks();
							int randomInt = new Random().nextInt(Bukkit.getOnlinePlayers().size());
							Player randomPlayer = (Player) Bukkit.getOnlinePlayers().toArray()[randomInt];
							Bukkit.broadcastMessage("                  ");
							Bukkit.broadcastMessage(Main.instance.cfg.getString("Prefix") + "�aDer Spieler �c" + randomPlayer.getName()+ " �ahat den Rang �e" + args[0] + " �agewonnen! HGW!");
							Bukkit.broadcastMessage("                  ");
						    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "pex user " + randomPlayer.getName() + " group set " + args[0]);
						    randomPlayer.kickPlayer("�cDu wurdest vom Server gekickt! \n\n �eGrund: �aNeuer Rang \n\n �bNeuer Rang: �6" + args[0]);
						    Bukkit.reload();
						}
					}
				}, 0L, 20L);
	        } else if (!p.hasPermission("skypvp.rang")) {
	            p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
	          }
	        } else
	        	p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cSyntax: /verlosung [Rang]");
	        
		
	return false;
	    }
}

