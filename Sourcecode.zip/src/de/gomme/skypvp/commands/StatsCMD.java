package de.gomme.skypvp.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.utils.Stats;

public class StatsCMD implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		
		Player p = (Player) sender;

		Stats stats = new Stats(p);
		

		p.sendMessage("�e------------ �8[�aStats�8] �e------------");
		p.sendMessage("�aStats von: �e" + stats.getPlayer().getName());
		p.sendMessage("             ");
		p.sendMessage("�aKills: �e" + stats.getKills());
		p.sendMessage("�aTode: �e" + stats.getDeaths());
		p.sendMessage("�aKD: �e" + stats.getKD());
		p.sendMessage("�e------------ �8[�aStats�8] �e------------");

			
		return false;

	}

}
