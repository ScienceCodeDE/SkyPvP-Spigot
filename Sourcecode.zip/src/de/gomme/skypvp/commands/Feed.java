package de.gomme.skypvp.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;

public class Feed implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

		if (sender instanceof Player) {
			Player p = (Player) sender;
			if (args.length == 0) {
				if (p.hasPermission("skypvp.feed")) {
					p.setFoodLevel(20);
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDein Hunger wurde erfolgreich geheilt!");
				} else
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
			}
		}
		return false;
	}
}
