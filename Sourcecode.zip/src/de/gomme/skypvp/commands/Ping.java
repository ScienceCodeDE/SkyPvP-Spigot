package de.gomme.skypvp.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;
import net.minecraft.server.v1_8_R3.EntityPlayer;

public class Ping implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

		if (sender instanceof Player) {
			Player p = (Player) sender;
			if (args.length == 0) {
				if (p.hasPermission("skypvp.spieler")) {
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast einen Ping von �e" + getPing(p) + " �ams");
				} else
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
			}
		}
		return false;
	
	}
	
	  public int getPing(Player p)
	  {
	    CraftPlayer pingc = (CraftPlayer)p;
	    EntityPlayer pinge = pingc.getHandle();
	    return pinge.ping;
	  }
}
