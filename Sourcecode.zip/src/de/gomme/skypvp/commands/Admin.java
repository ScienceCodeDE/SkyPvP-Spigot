package de.gomme.skypvp.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.events.ScoreboardMA;
import de.gomme.skypvp.main.Main;

public class Admin implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

		if (sender instanceof Player) {
			Player p = (Player) sender;
			if (args.length == 0) {
				if (p.hasPermission("skypvp.admin")) {
					p.sendMessage("                         ");
					p.sendMessage("�e-=-=- �aAdmin �e-=-=-");
					p.sendMessage("                         ");
					p.sendMessage("�ahttp://veromc.ml/admin.html");
					p.sendMessage("                         ");
					p.sendMessage("�6-> �a/admin reload �7- �eReloade den Server");
					p.sendMessage("�6-> �a/admin status_wartungen �7- �eZeigt dir den Status im WartungsSystem.");
					p.sendMessage("�6-> �a/admin updatescoreboard �7- �eUpdate den Scoreboard!");
					p.sendMessage("�6-> �a/admin gethead �7- �eGibt dir den Kopf f�r den CookieClicker!");
					p.sendMessage("                         ");

				} else
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");

			} else if (args[0].equalsIgnoreCase("reload")) {

				Bukkit.broadcastMessage("                 ");
				Bukkit.broadcastMessage("�cAchtung: �aEs wird nun kurz einen Lag geben!");
				Bukkit.broadcastMessage("�aKeine Sorge es gehen keine Items verloren!");
				Bukkit.broadcastMessage("                 ");
				Bukkit.reload();

			} else if (args[0].equalsIgnoreCase("gethead")) {
				p.performCommand("head QuadratCookie");
			} else if (args[0].equalsIgnoreCase("updatescoreboard")) {
				ScoreboardMA.setBoard(p);
			} else if (args[0].equalsIgnoreCase("status_wartungen")) {
				p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDie Wartungen sind derzeit auf �c" + Main.instance.wartung);
			}

		}

		return false;
	}
}
