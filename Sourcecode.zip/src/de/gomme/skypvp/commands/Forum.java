package de.gomme.skypvp.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;

public class Forum implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		
		Player p = (Player)sender;
		
			p.sendMessage("                     ");
			p.sendMessage("�e-=-=-=- �e�lForum �r�e-=-=-=-");
			p.sendMessage("                     ");
			p.sendMessage("�a-=- " + Main.instance.cfg.getString("Links.Forum") + " �a-=-");
			p.sendMessage("                     ");
			p.sendMessage("�e-=-=-=- �e�lForum �r�e-=-=-=-");
			p.sendMessage("                     ");


		return false;
		
	}
	
}
