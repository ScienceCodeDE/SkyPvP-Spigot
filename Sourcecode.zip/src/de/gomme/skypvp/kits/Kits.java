package de.gomme.skypvp.kits;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import de.NeonnBukkit.CoinsAPI.API.CoinsAPI;
import de.gomme.skypvp.main.Main;

public class Kits implements Listener, CommandExecutor {
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

		List<String> lore1 = new ArrayList<String>();
		
		if (sender instanceof Player) {
			Player p = (Player) sender;
			if (args.length == 0) {
					Inventory inv = Bukkit.createInventory(null, 9 * 3, "§aKits");

					ItemStack a1 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a1meta = a1.getItemMeta();
					a1meta.setDisplayName(" ");
					a1meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a1meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
					a1.setItemMeta(a1meta);

					ItemStack a2 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a2meta = a2.getItemMeta();
					a2meta.setDisplayName(" ");
					a2meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a2meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a2.setItemMeta(a2meta);

					ItemStack a3 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a3meta = a3.getItemMeta();
					a3meta.setDisplayName(" ");
					a3meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a3meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a3.setItemMeta(a3meta);

					ItemStack a4 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a4meta = a4.getItemMeta();
					a4meta.setDisplayName(" ");
					a4meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a4meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a4.setItemMeta(a4meta);

					ItemStack a5 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a5meta = a5.getItemMeta();
					a5meta.setDisplayName(" ");
					a5meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a5meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a5.setItemMeta(a5meta);

					ItemStack a6 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a6meta = a6.getItemMeta();
					a6meta.setDisplayName(" ");
					a6meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a6meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a6.setItemMeta(a6meta);

					ItemStack a7 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a7meta = a7.getItemMeta();
					a7meta.setDisplayName(" ");
					a7meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a7meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a7.setItemMeta(a7meta);

					ItemStack a8 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a8meta = a8.getItemMeta();
					a8meta.setDisplayName(" ");
					a8meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a8meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a8.setItemMeta(a8meta);

					ItemStack a9 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a9meta = a9.getItemMeta();
					a9meta.setDisplayName(" ");
					a9meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a9meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a9.setItemMeta(a9meta);

					ItemStack a10 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a10meta = a10.getItemMeta();
					a10meta.setDisplayName(" ");
					a10meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a10meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a10.setItemMeta(a10meta);

					ItemStack a11 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a11meta = a11.getItemMeta();
					a11meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a11meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a11meta.setDisplayName(" ");
					a11.setItemMeta(a11meta);

					ItemStack a12 = new ItemStack(Material.GOLD_CHESTPLATE);
					ItemMeta a12meta = a12.getItemMeta();
					a12meta.setDisplayName("§8» §6Gold Kit §8«");
					a12.setItemMeta(a12meta);

					ItemStack a13 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a13meta = a13.getItemMeta();
					a13meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a13meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a13meta.setDisplayName(" ");
					a13.setItemMeta(a13meta);

					ItemStack a14 = new ItemStack(Material.IRON_CHESTPLATE);
					ItemMeta a14meta = a14.getItemMeta();
					a14meta.setDisplayName("§8» §9Diamond Kit §8«");
					a14.setItemMeta(a14meta);

					ItemStack a15 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a15meta = a15.getItemMeta();
					a15meta.setDisplayName(" ");
					a15meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a15meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a15.setItemMeta(a15meta);

					ItemStack a16 = new ItemStack(Material.DIAMOND_CHESTPLATE);
					ItemMeta a16meta = a16.getItemMeta();
					a16meta.setDisplayName("§8» §eHero Kit §8«");
					a16.setItemMeta(a16meta);

					ItemStack a17 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a17meta = a17.getItemMeta();
					a17meta.setDisplayName(" ");
					a17meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a17meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a17.setItemMeta(a17meta);

					ItemStack a18 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a18meta = a18.getItemMeta();
					a18meta.setDisplayName(" ");
					a18meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a18meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a18.setItemMeta(a18meta);

					ItemStack a19 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a19meta = a19.getItemMeta();
					a19meta.setDisplayName(" ");
					a19meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a19meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a19.setItemMeta(a19meta);

					ItemStack a20 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a20meta = a20.getItemMeta();
					a20meta.setDisplayName(" ");
					a20meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a20meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a20.setItemMeta(a20meta);

					ItemStack a21 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a21meta = a21.getItemMeta();
					a21meta.setDisplayName(" ");
					a21meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a21meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a21.setItemMeta(a21meta);

					ItemStack a22 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a22meta = a22.getItemMeta();
					a22meta.setDisplayName(" ");
					a22meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a22meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a22.setItemMeta(a22meta);

					ItemStack a23 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a23meta = a23.getItemMeta();
					a23meta.setDisplayName(" ");
					a23meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a23meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a23.setItemMeta(a23meta);

					ItemStack a24 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a24meta = a24.getItemMeta();
					a24meta.setDisplayName(" ");
					a24meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a24meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a24.setItemMeta(a24meta);

					ItemStack a25 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a25meta = a25.getItemMeta();
					a25meta.setDisplayName(" ");
					a25meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a25meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a25.setItemMeta(a25meta);

					ItemStack a26 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a26meta = a26.getItemMeta();
					a26meta.setDisplayName(" ");
					a26meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a26meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a26.setItemMeta(a26meta);

					ItemStack a27 = new ItemStack(Material.STAINED_GLASS_PANE);
					ItemMeta a27meta = a27.getItemMeta();
					a27meta.setDisplayName(" ");
					a27meta.addEnchant(Enchantment.DAMAGE_ALL, -1, true);
					a27meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

					a27.setItemMeta(a27meta);

					inv.setItem(0, a1);
					inv.setItem(1, a2);
					inv.setItem(2, a3);
					inv.setItem(3, a4);
					inv.setItem(4, a5);
					inv.setItem(5, a6);
					inv.setItem(6, a7);
					inv.setItem(7, a8);
					inv.setItem(8, a9);
					inv.setItem(9, a10);
					inv.setItem(10, a11);
					inv.setItem(11, a12);
					inv.setItem(12, a13);
					inv.setItem(13, a14);
					inv.setItem(14, a15);
					inv.setItem(15, a16);
					inv.setItem(16, a17);
					inv.setItem(17, a18);
					inv.setItem(18, a19);
					inv.setItem(19, a20);
					inv.setItem(20, a21);
					inv.setItem(21, a22);
					inv.setItem(22, a23);
					inv.setItem(23, a24);
					inv.setItem(24, a25);
					inv.setItem(25, a26);
					inv.setItem(26, a27);

					p.openInventory(inv);

			}
		}
		return false;
	}

	@EventHandler
	public void on(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();

		if (e.getInventory().getName().equalsIgnoreCase("§aKits")) {
			try {
				if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(" ")) {
					e.getView().close();
					e.setCancelled(true);
				}
				if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§8» §6Gold Kit §8«")) {
					if(p.hasPermission("skypvp.gold")) {
						
                        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
                        ItemStack pickaxe = new ItemStack(Material.DIAMOND_PICKAXE);
                        ItemStack rod = new ItemStack(Material.FISHING_ROD);
                        ItemStack apple = new ItemStack(Material.GOLDEN_APPLE);
                        ItemStack rüsi1 = new ItemStack(Material.GOLD_HELMET);
                        ItemStack rüsi2 = new ItemStack(Material.IRON_CHESTPLATE);
                        ItemStack rüsi3 = new ItemStack(Material.IRON_LEGGINGS);
                        ItemStack rüsi4 = new ItemStack(Material.GOLD_BOOTS);


						p.getInventory().addItem(sword, pickaxe, rod, rüsi1, rüsi2, rüsi3, rüsi4, apple);
						
					e.getView().close();
					} else {
						p.sendMessage(Main.instance.cfg.getString("Prefix") + "§cDazu hast du keine Rechte!");
						e.getView().close();

					}
				}
				else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§8» §9Diamond Kit §8«")) {
					if(p.hasPermission("skypvp.diamond")) {
						
                        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
                        ItemStack pickaxe = new ItemStack(Material.DIAMOND_PICKAXE);
                        ItemStack rod = new ItemStack(Material.FISHING_ROD);
                        ItemStack apple = new ItemStack(Material.GOLDEN_APPLE);
                        ItemStack rüsi1 = new ItemStack(Material.IRON_HELMET);
                        ItemStack rüsi2 = new ItemStack(Material.DIAMOND_CHESTPLATE);
                        ItemStack rüsi3 = new ItemStack(Material.DIAMOND_LEGGINGS);
                        ItemStack rüsi4 = new ItemStack(Material.IRON_BOOTS);


						
						p.getInventory().addItem(sword, pickaxe, rod, rüsi1, rüsi2, rüsi3, rüsi4, apple);
						
					e.getView().close();
					} else {
						p.sendMessage(Main.instance.cfg.getString("Prefix") + "§cDazu hast du keine Rechte!");
						e.getView().close();

					}
				}

				else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§8» §eHero Kit §8«")) {
					if(p.hasPermission("skypvp.hero")) {
						
                        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
                        ItemStack pickaxe = new ItemStack(Material.DIAMOND_PICKAXE);
                        ItemStack rod = new ItemStack(Material.FISHING_ROD);
                        ItemStack apple = new ItemStack(Material.GOLDEN_APPLE, 1, (short) 1);
                        ItemStack rüsi = new ItemStack(Material.DIAMOND_HELMET);
                        ItemStack rüsi2 = new ItemStack(Material.DIAMOND_CHESTPLATE);
                        ItemStack rüsi3 = new ItemStack(Material.DIAMOND_LEGGINGS);
                        ItemStack rüsi4 = new ItemStack(Material.DIAMOND_BOOTS);


						
						p.getInventory().addItem(sword, pickaxe, rod, rüsi, rüsi2, rüsi3, rüsi4, apple);
						
					e.getView().close();
					} else {
						p.sendMessage(Main.instance.cfg.getString("Prefix") + "§cDazu hast du keine Rechte!");
						e.getView().close();

					}
				}
			} catch (Exception ex) {

			}
		}
	}
}
