package de.gomme.skypvp.reportsystem;

import java.util.ArrayList;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import de.gomme.skypvp.main.Main;

public class Spectate
  implements CommandExecutor
{
  private ArrayList<Player> vanished = new ArrayList();
  
  public void onEnable() {}
  
  public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args)
  {
    if (!(sender instanceof Player))
    {
      sender.sendMessage(Main.instance.cfg.getString("Prefix") + "Du musst ein Spieler sein!");
      return true;
    }
    Player p = (Player)sender;
    if ((p.hasPermission("skypvp.team")) && 
      ((sender instanceof Player)))
    {
      if (!this.vanished.contains(p))
      {
        for (Player pl : Bukkit.getServer().getOnlinePlayers()) {
          pl.hidePlayer(p);
        }
        this.vanished.add(p);
        p.sendMessage(Main.instance.cfg.getString("Prefix") + "�eDu bist nun im Spectator-Modus!");
        p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aBenutze �e/spec �aum dich wieder �esichtbar �azu machen.");
        p.setGameMode(GameMode.SPECTATOR);
        
        return false;
      }
      for (Player pl : Bukkit.getServer().getOnlinePlayers()) {
        pl.showPlayer(p);
      }
      this.vanished.remove(p);
      
      p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu bist nun nicht mehr im Spectator-Modus");
      p.setGameMode(GameMode.SURVIVAL);
      return false;
    }
    return false;
  }
  
  @EventHandler
  public void onPlayerJoin(PlayerJoinEvent e)
  {
    for (Player p : this.vanished) {
      e.getPlayer().hidePlayer(p);
    }
  }
  
  @EventHandler
  public void onPlayerLeave(PlayerQuitEvent e)
  {
    this.vanished.remove(e.getPlayer());
  }
}
