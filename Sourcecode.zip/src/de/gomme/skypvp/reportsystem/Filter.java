package de.gomme.skypvp.reportsystem;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import de.gomme.skypvp.main.Main;

public class Filter
  implements Listener
{
  @EventHandler
  public void on(AsyncPlayerChatEvent e)
  {
    Player p = e.getPlayer();
    String msg = e.getMessage();
    
    List<String> blocked = new ArrayList();
    
    blocked.add("hacker");
    blocked.add("hax");
    blocked.add("HACKER");
    blocked.add("HAX");
   
    blocked.add("Scheiss");
    blocked.add("SCHEISS");
    
    blocked.add("Fuck");
    blocked.add("FUCK");
    
    blocked.add("SCHEI�");
    blocked.add("scheiss");
    
    blocked.add("Fick");
    blocked.add("FICK");
    blocked.add("fick");
    
    blocked.add("Hilter");
    blocked.add("Hilter");
    blocked.add("HITLER");
    blocked.add("hitler");
    blocked.add("hilter");
    
    blocked.add("hure");
    blocked.add("huan");
    blocked.add("Huan");
    blocked.add("HUAN");
    blocked.add("HURE");
    blocked.add("Hure");
    
    blocked.add("ez");
    blocked.add("EZ");
    blocked.add("eZ");
    blocked.add("Ez");
    blocked.add("3z");
    blocked.add("ezzz");
    
    blocked.add("noob");
    blocked.add("NOOB");
    blocked.add("Noob");
    blocked.add("N00B");
    blocked.add("Nooob");
    blocked.add("nab");
    blocked.add("NAB");
    blocked.add("Naab");
    if (!p.hasPermission("skypvp.allow")) {
      for (String block : blocked) {
        if (msg.contains(block))
        {
          e.setCancelled(true);
          String replace = "";
          for (int i = 0; i < block.length(); i++) {
            replace = replace + "#";
          }
          String NewMessage = msg.replace(block, replace);
          e.setMessage(NewMessage);
          p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDu hast versucht ein Wort zu sagen, welches hier nicht erlaubt ist!");
          for (Player allPlayers : Bukkit.getOnlinePlayers()) {
            if (allPlayers.hasPermission("skypvp.team"))
            {
              allPlayers.sendMessage(Main.instance.cfg.getString("Prefix") + "�4" + p.getName() + "�c hat versucht ein verbotenes Wort zu sagen!");
              allPlayers.sendMessage(Main.instance.cfg.getString("Prefix") + "�cBeleidigung: �e" + block);
            }
          }
        }
      }
    }
  }
}
