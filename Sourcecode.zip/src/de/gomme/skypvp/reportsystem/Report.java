package de.gomme.skypvp.reportsystem;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;

public class Report implements CommandExecutor {
	public boolean onCommand(CommandSender sender, Command cmd, String Commandlabel, String[] args) {
		if ((sender instanceof Player)) {
			String myString = "";
			for (int i = 0; i < args.length; i++) {
				String arg = args[i] + " ";
				myString = myString + arg;
			}
			Player p = (Player) sender;
			if (args.length == 0) {
				p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cSyntax: /report [Spieler] [Grund]");
				return true;
			}
			if (!args[0].equalsIgnoreCase(p.getName())) {
				Player target = p.getServer().getPlayerExact(args[0]);
				if (target != null) {
					p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDanke f�r's reporten! Ein Teammitglied wird sich schnellstens darum k�mmern!");
					for (Player allPlayers : Bukkit.getOnlinePlayers()) {
						if (allPlayers.hasPermission("skypvp.team")) {
							allPlayers.sendMessage(Main.instance.cfg.getString("Prefix") + "�c-=-=- �eReport �c-=-=-");
							allPlayers.sendMessage(Main.instance.cfg.getString("Prefix") + "�c" + target.getName() + "�a wurde von �e" + p.getName() + "�a reported.");
							allPlayers.sendMessage(Main.instance.cfg.getString("Prefix") + "�cGrund: �4" + myString.replace(target.getName(), ""));
							allPlayers.sendMessage(Main.instance.cfg.getString("Prefix") + "�c-=-=- �eReport �c-=-=-");

						}
					}
				} else {
					sender.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDieser Spieler ist nicht Online!");
				}
				return true;
			}
			p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDu darfst dich nicht selber reporten!");
		}
		return false;
	}
}
