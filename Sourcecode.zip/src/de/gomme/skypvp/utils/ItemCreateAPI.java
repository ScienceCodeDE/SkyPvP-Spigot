package de.gomme.skypvp.utils;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

public class ItemCreateAPI
{
  public static ItemStack create(int id, int subid, int amount, String DisplayName)
  {
    ItemStack is = new ItemStack(id, amount, (short)subid);
    ItemMeta im = is.getItemMeta();
    im.setDisplayName(DisplayName);
    is.setItemMeta(im);
    return is;
  }
  
  public static ItemStack createHead(String PlayerName, String name, int amount)
  {
    ItemStack itemstack = new ItemStack(Material.SKULL_ITEM, amount, (short)3);
    SkullMeta meta = (SkullMeta)itemstack.getItemMeta();
    meta.setOwner(PlayerName);
    meta.setDisplayName(name);
    itemstack.setItemMeta(meta);
    return itemstack;
  }
}
