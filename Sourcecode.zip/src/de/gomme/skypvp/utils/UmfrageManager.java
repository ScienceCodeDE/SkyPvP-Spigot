package de.gomme.skypvp.utils;

import java.io.File;
import java.io.IOException;
import java.util.List;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class UmfrageManager
{
  private static File file = new File("plugins/SkyPvP-System", "umfrage.yml");
  private static FileConfiguration configuration = YamlConfiguration.loadConfiguration(file);
  
  private static void save(File file, FileConfiguration configuration)
  {
    try
    {
      configuration.save(file);
    }
    catch (IOException localIOException) {}
  }
  
  private static List<String> voted = configuration.getStringList("voted");
  
  public static boolean hasVoted(String uuid)
  {
    return voted.contains(uuid);
  }
  
  public static void createUmfrage(String umfrage)
  {
    configuration.set("umfrage", umfrage);
    save(file, configuration);
  }
  
  public static String getCurrentUmfrage()
  {
    return configuration.getString("umfrage");
  }
  
  public static boolean runsUmfrage()
  {
    return file.exists();
  }
  
  public static void deleteUmfrage()
  {
    file.delete();
    voted.clear();
    voted.remove(getVotes());
    voted.removeIf(null);
  }
  
  public static int getYes()
  {
    return configuration.getInt("yes");
  }
  
  public static int getNo()
  {
    return configuration.getInt("no");
  }
  
  public static void voteYes(String uuid)
  {
    int yes = getYes() + 1;
    configuration.set("yes", Integer.valueOf(yes));
    voted.add(uuid);
    configuration.set("voted", voted);
    save(file, configuration);
  }
  
  public static void voteNo(String uuid)
  {
    int no = getNo() + 1;
    configuration.set("no", Integer.valueOf(no));
    voted.add(uuid);
    configuration.set("voted", voted);
    save(file, configuration);
  }
  
  public static int getVotes()
  {
    return voted.size();
  }
}
