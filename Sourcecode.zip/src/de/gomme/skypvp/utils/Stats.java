package de.gomme.skypvp.utils;

import de.gomme.skypvp.utils.MySQL;
import org.bukkit.entity.Player;

public class Stats
{
  private Player player;
  private Integer kills;
  private Integer deaths;
  private Integer wins;
  private Double kd;
  private Integer played;
  private Integer looses;
  
  public Stats(Player p)
  {
    this.player = p;
    this.kills = MySQL.getKills(p.getUniqueId().toString());
    this.deaths = MySQL.getDeaths(p.getUniqueId().toString());
    this.wins = MySQL.getWins(p.getUniqueId().toString());
    this.played = MySQL.getPlayed(p.getUniqueId().toString());
    this.looses = Integer.valueOf(this.played.intValue() - this.wins.intValue());
    if (this.deaths.intValue() == 0)
    {
      this.kd = Double.valueOf(this.kills.intValue());
    }
    else
    {
      this.kd = Double.valueOf(this.kills.intValue() / this.deaths.intValue());
      this.kd = Double.valueOf(Math.round(100.0D * this.kd.doubleValue()) / 100.0D);
    }
  }
  
  public Player getPlayer()
  {
    return this.player;
  }
  
  public Integer getKills()
  {
    return this.kills;
  }
  
  public Integer getDeaths()
  {
    return this.deaths;
  }
  
  public Integer getWins()
  {
    return this.wins;
  }
  
  public Integer getPlayedGames()
  {
    return this.played;
  }
  
  public Integer getLooses()
  {
    return this.looses;
  }
  
  public Double getKD()
  {
    return this.kd;
  }
  
  public void addDeath()
  {
    MySQL.addDeath(this.player.getUniqueId().toString());
  }
  
  public void addKill()
  {
    MySQL.addKill(this.player.getUniqueId().toString());
  }
  
  public void addPlayedGame()
  {
    MySQL.addPlayed(this.player.getUniqueId().toString());
  }
  
  public void addWin()
  {
    MySQL.addWin(this.player.getUniqueId().toString());
  }
}
