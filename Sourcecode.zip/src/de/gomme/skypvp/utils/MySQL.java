package de.gomme.skypvp.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import de.gomme.skypvp.main.Main;

public class MySQL {
	private String HOST = "";
	private String DATABASE = "";
	private String USER = "";
	private String PASSWORD = "";
	private Connection con;

	public MySQL(String host, String database, String user, String password) {
		this.HOST = host;
		this.DATABASE = database;
		this.USER = user;
		this.PASSWORD = password;

		connect();
	}

	public void connect() {
		try {
			this.con = DriverManager.getConnection(
					"jdbc:mysql://" + this.HOST + ":3306/" + this.DATABASE + "?autoReconnect=true", this.USER,
					this.PASSWORD);
			System.out.println("[MySQL] Die Verbindung zur MySQL wurde hergestellt!");
		} catch (SQLException e) {
			System.out.println("[MySQL] Die Verbindung zur MySQL ist fehlgeschlagen! Fehler: " + e.getMessage());
		}
	}

	public void close() {
		try {
			if (this.con != null) {
				this.con.close();
				System.out.println("[MySQL] Die Verbindung zur MySQL wurde Erfolgreich beendet!");
			}
		} catch (SQLException e) {
			System.out.println("[MySQL] Fehler beim beenden der Verbindung zur MySQL! Fehler: " + e.getMessage());
		}
	}

	public void update(String qry) {
		try {
			Statement st = this.con.createStatement();
			st.executeUpdate(qry);
			st.close();
		} catch (SQLException e) {
			connect();
			System.err.println(e);
		}
	}

	public ResultSet query(String qry) {
		ResultSet rs = null;
		try {
			Statement st = this.con.createStatement();
			rs = st.executeQuery(qry);
		} catch (SQLException e) {
			connect();
			System.err.println(e);
		}
		return rs;
	}

	public static boolean playerExists(String uuid) {
		try {
			ResultSet rs = Main.mysql.query("SELECT * FROM StatsAPI WHERE UUID= '" + uuid + "'");
			if (rs.next()) {
				return rs.getString("UUID") != null;
			}
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public static void createPlayer(String uuid) {
		if (!playerExists(uuid)) {
			Main.mysql.update("INSERT INTO StatsAPI (UUID, KILLS, DEATHS, PLAY, WINS) VALUES ('" + uuid
					+ "', '0', '0', '0', '0');");
		}
	}

	public static Integer getKills(String uuid) {
		Integer i = Integer.valueOf(0);
		if (playerExists(uuid)) {
			try {
				ResultSet rs = Main.mysql.query("SELECT * FROM StatsAPI WHERE UUID= '" + uuid + "'");
				if ((rs.next()) && (Integer.valueOf(rs.getInt("KILLS")) == null)) {
				}
				i = Integer.valueOf(rs.getInt("KILLS"));
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			createPlayer(uuid);
			getKills(uuid);
		}
		return i;
	}

	public static Integer getDeaths(String uuid) {
		Integer i = Integer.valueOf(0);
		if (playerExists(uuid)) {
			try {
				ResultSet rs = Main.mysql.query("SELECT * FROM StatsAPI WHERE UUID= '" + uuid + "'");
				if ((rs.next()) && (Integer.valueOf(rs.getInt("DEATHS")) == null)) {
				}
				i = Integer.valueOf(rs.getInt("DEATHS"));
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			createPlayer(uuid);
			getKills(uuid);
		}
		return i;
	}

	public static Integer getWins(String uuid) {
		Integer i = Integer.valueOf(0);
		if (playerExists(uuid)) {
			try {
				ResultSet rs = Main.mysql.query("SELECT * FROM StatsAPI WHERE UUID= '" + uuid + "'");
				if ((rs.next()) && (Integer.valueOf(rs.getInt("WINS")) == null)) {
				}
				i = Integer.valueOf(rs.getInt("WINS"));
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			createPlayer(uuid);
			getKills(uuid);
		}
		return i;
	}

	public static Integer getPlayed(String uuid) {
		Integer i = Integer.valueOf(0);
		if (playerExists(uuid)) {
			try {
				ResultSet rs = Main.mysql.query("SELECT * FROM StatsAPI WHERE UUID= '" + uuid + "'");
				if ((rs.next()) && (Integer.valueOf(rs.getInt("PLAY")) == null)) {
				}
				i = Integer.valueOf(rs.getInt("PLAY"));
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			createPlayer(uuid);
			getKills(uuid);
		}
		return i;
	}

	public static void setKills(String uuid, Integer kills) {
		if (playerExists(uuid)) {
			Main.mysql.update("UPDATE StatsAPI SET KILLS= '" + kills + "' WHERE UUID= '" + uuid + "';");
		} else {
			createPlayer(uuid);
			setKills(uuid, kills);
		}
	}

	public static void setDeaths(String uuid, Integer deaths) {
		if (playerExists(uuid)) {
			Main.mysql.update("UPDATE StatsAPI SET DEATHS= '" + deaths + "' WHERE UUID= '" + uuid + "';");
		} else {
			createPlayer(uuid);
			setDeaths(uuid, deaths);
		}
	}

	public static void setPlayed(String uuid, Integer played) {
		if (playerExists(uuid)) {
			Main.mysql.update("UPDATE StatsAPI SET PLAY= '" + played + "' WHERE UUID= '" + uuid + "';");
		} else {
			createPlayer(uuid);
			setPlayed(uuid, played);
		}
	}

	public static void setWins(String uuid, Integer wins) {
		if (playerExists(uuid)) {
			Main.mysql.update("UPDATE StatsAPI SET WINS= '" + wins + "' WHERE UUID= '" + uuid + "';");
		} else {
			createPlayer(uuid);
			setKills(uuid, wins);
		}
	}

	public static void addKill(String uuid) {
		Integer i = Integer.valueOf(1);
		if (playerExists(uuid)) {
			setKills(uuid, Integer.valueOf(getKills(uuid).intValue() + i.intValue()));
		} else {
			createPlayer(uuid);
			addKill(uuid);
		}
	}

	public static void addDeath(String uuid) {
		Integer i = Integer.valueOf(1);
		if (playerExists(uuid)) {
			setDeaths(uuid, Integer.valueOf(getDeaths(uuid).intValue() + i.intValue()));
		} else {
			createPlayer(uuid);
			addDeath(uuid);
		}
	}

	public static void addWin(String uuid) {
		Integer i = Integer.valueOf(1);
		if (playerExists(uuid)) {
			setWins(uuid, Integer.valueOf(getWins(uuid).intValue() + i.intValue()));
		} else {
			createPlayer(uuid);
			addWin(uuid);
		}
	}

	public static void addPlayed(String uuid) {
		Integer i = Integer.valueOf(1);
		if (playerExists(uuid)) {
			setPlayed(uuid, Integer.valueOf(getPlayed(uuid).intValue() + i.intValue()));
		} else {
			createPlayer(uuid);
			addPlayed(uuid);
		}
	}
}
