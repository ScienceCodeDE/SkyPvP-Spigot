package de.gomme.skypvp.events;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import de.gomme.skypvp.main.Main;

public class OnJoin implements Listener {

	@EventHandler(priority = EventPriority.HIGHEST)
	public void onJoin(PlayerJoinEvent e) {
		Player p = e.getPlayer();

		p.teleport(p.getWorld().getSpawnLocation());

		if (!p.hasPlayedBefore()) {
			Bukkit.broadcastMessage("               ");
			Bukkit.broadcastMessage(Main.instance.cfg.getString("Prefix") + "�e" + p.getName() + "�aist neu auf dem SkyPvP Server!");
			Bukkit.broadcastMessage("               ");
			
		ScoreboardMA.setBoard(p);
			

					}

	}
}
