package de.gomme.skypvp.events;

import org.bukkit.Material;
import org.bukkit.block.Skull;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import de.NeonnBukkit.CoinsAPI.API.CoinsAPI;
import de.gomme.skypvp.main.Main;

public class ClickTest implements Listener {
	
  @EventHandler
  public void onInt(PlayerInteractEvent e)
  {
    Player p = e.getPlayer();
    if ((e.getAction() == Action.RIGHT_CLICK_BLOCK) && 
      (e.getClickedBlock().getType() == Material.SKULL))
    {
    	Skull skull = (Skull)e.getClickedBlock().getState();
        if (skull.getOwner().equalsIgnoreCase(Main.instance.cfg.getString("CookieClicker.Name")))
        {
    	p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast erfolgreich ein Coin hinzugef�gt bekommen!");
    	CoinsAPI.addCoins(p.getUniqueId().toString(), 1);
    	ScoreboardMA.setBoard(p);
    	

    }
  }
  }
}