package de.gomme.skypvp.events;

import java.io.File;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import de.gomme.skypvp.main.Main;

public class ChatFormat implements Listener {
	
	
	@EventHandler
	public void onChat(AsyncPlayerChatEvent e) {
		Player p = (Player)e.getPlayer();
	    String msg = e.getMessage();

		if(p.hasPermission(Main.instance.cfg.getString("Chat.Permission1"))) {
			e.setFormat(Main.instance.cfg.getString("Chat.1").replaceAll("&", "�").replaceAll("%player%", p.getName()).replaceAll("%msg%", e.getMessage()));
		} else if(p.hasPermission(Main.instance.cfg.getString("Chat.Permission2"))) {
			e.setFormat(Main.instance.cfg.getString("Chat.2").replaceAll("&", "�").replaceAll("%player%", p.getName()).replaceAll("%msg%", e.getMessage()));
		} else if(p.hasPermission(Main.instance.cfg.getString("Chat.Permission3"))) {
			e.setFormat(Main.instance.cfg.getString("Chat.3").replaceAll("&", "�").replaceAll("%player%", p.getName()).replaceAll("%msg%", e.getMessage()));
		} else if(p.hasPermission(Main.instance.cfg.getString("Chat.Permission4"))) {
			e.setFormat(Main.instance.cfg.getString("Chat.4").replaceAll("&", "�").replaceAll("%player%", p.getName()).replaceAll("%msg%", e.getMessage()));
		} else if(p.hasPermission(Main.instance.cfg.getString("Chat.Permission5"))) {
			e.setFormat(Main.instance.cfg.getString("Chat.5").replaceAll("&", "�").replaceAll("%player%", p.getName()).replaceAll("%msg%", e.getMessage()));
		} else if(p.hasPermission(Main.instance.cfg.getString("Chat.Permission6"))) {
			e.setFormat(Main.instance.cfg.getString("Chat.6").replaceAll("&", "�").replaceAll("%player%", p.getName()).replaceAll("%msg%", e.getMessage()));
		} else if(p.hasPermission(Main.instance.cfg.getString("Chat.Permission7"))) {
			e.setFormat(Main.instance.cfg.getString("Chat.7").replaceAll("&", "�").replaceAll("%player%", p.getName()).replaceAll("%msg%", e.getMessage()));
		} else if(p.hasPermission(Main.instance.cfg.getString("Chat.Permission8"))) {
			e.setFormat(Main.instance.cfg.getString("Chat.8").replaceAll("&", "�").replaceAll("%player%", p.getName()).replaceAll("%msg%", e.getMessage()));
		} else if(p.hasPermission(Main.instance.cfg.getString("Chat.Permission9"))) {
			e.setFormat(Main.instance.cfg.getString("Chat.9").replaceAll("&", "�").replaceAll("%player%", p.getName()).replaceAll("%msg%", e.getMessage()));
		} else if(p.hasPermission(Main.instance.cfg.getString("Chat.Permission10"))) {
			e.setFormat(Main.instance.cfg.getString("Chat.10").replaceAll("&", "�").replaceAll("%player%", p.getName()).replaceAll("%msg%", e.getMessage()));
		} else if(p.hasPermission(Main.instance.cfg.getString("Chat.Permission11"))) {
			e.setFormat(Main.instance.cfg.getString("Chat.11").replaceAll("&", "�").replaceAll("%player%", p.getName()).replaceAll("%msg%", e.getMessage()));
		} else {
			e.setFormat(Main.instance.cfg.getString("Chat.12").replaceAll("&", "�").replaceAll("%player%", p.getName()).replaceAll("%msg%", e.getMessage()));



		}
					
		}
}

