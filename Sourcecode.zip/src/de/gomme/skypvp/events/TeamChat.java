package de.gomme.skypvp.events;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChatEvent;

import de.gomme.skypvp.main.Main;

public class TeamChat
  implements Listener
{
  @EventHandler
  public void onChat(PlayerChatEvent e)
  {
    Player p = e.getPlayer();
    if ((p.hasPermission("skypvp.team")) && 
      (e.getMessage().startsWith(Main.instance.cfg.getString("TeamChat.Command")))) {
      for (Player a : Bukkit.getOnlinePlayers())
      {
        if (a.hasPermission("skypvp.team")) {
          a.sendMessage(Main.instance.cfg.getString("Prefix") + "�c" + p.getDisplayName() + " �8| �b" + e.getMessage().replaceAll("@t", ""));
        }
        e.setCancelled(true);
      }
    }
  }
}
