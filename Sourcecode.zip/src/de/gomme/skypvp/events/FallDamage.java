package de.gomme.skypvp.events;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

import de.gomme.skypvp.main.Main;

public class FallDamage
  implements Listener
{
  public FallDamage(Main main) {
	}

@EventHandler
  public void onDamage(EntityDamageEvent e)
  {
    if (e.getCause().equals(EntityDamageEvent.DamageCause.FALL)) {
      e.setCancelled(true);
    }
  }
}