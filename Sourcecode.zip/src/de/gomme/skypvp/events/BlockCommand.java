package de.gomme.skypvp.events;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.Plugin;

import de.gomme.skypvp.main.Main;;

public class BlockCommand implements Listener {

	  @EventHandler
	  public void onCommand(PlayerCommandPreprocessEvent e)
	  {
	    Player p = e.getPlayer();
	    if (p.isOp()) {
	      return;
	    }
	    if ((e.getMessage().startsWith("/bukkit:me")) || (e.getMessage().startsWith("/bukkit:pl")) || (e.getMessage().startsWith("/bukkit:help")) || (e.getMessage().startsWith("/bukkit:tell")) || 
	      (e.getMessage().startsWith("/pl")) || (e.getMessage().startsWith("/PL")) || (e.getMessage().startsWith("/bukkit:PL")) || (e.getMessage().startsWith("/Plugins")) || (e.getMessage().startsWith("/PLUGINS")) || (e.getMessage().startsWith("/help")) || (e.getMessage().startsWith("/?") || (e.getMessage().startsWith("/ver") || (e.getMessage().startsWith("/version") || (e.getMessage().startsWith("/icanhasbukkit")|| (e.getMessage().startsWith("/bukkit:ver") || (e.getMessage().startsWith("/bukkit:version") || (e.getMessage().startsWith("/op")))))))))
	    {
	      e.setCancelled(true);
	    p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");  
	    }
	  }
}
