package de.gomme.skypvp.events;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public class DeathHigh implements Listener {

	@EventHandler
	public void onMove(PlayerMoveEvent e) {
	    if (((e.getPlayer() instanceof Player)) && (e.getPlayer() != null) && 
	    	      (!e.getPlayer().isDead()) && 
	    	      (e.getPlayer().getLocation().getY() < 0.0D)) {
	    	e.getPlayer().setHealth(0.0D);
	    }
	}
}
