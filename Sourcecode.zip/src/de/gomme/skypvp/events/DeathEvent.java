package de.gomme.skypvp.events;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import de.gomme.skypvp.utils.Stats;

public class DeathEvent
  implements Listener
{
  
  @EventHandler
  public void onDeath(PlayerDeathEvent e)
  {
    Player p = e.getEntity();
    Player killer = e.getEntity().getKiller();
	Stats stats = new Stats(p);
	
	p.spigot().respawn();
    stats.addDeath();
    stats.getKD();
    if ((killer instanceof Player))
    {
    	stats.addKill();
    	stats.getKD();
    }
  }
}