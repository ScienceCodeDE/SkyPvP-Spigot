package de.gomme.skypvp.events;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import de.gomme.skypvp.main.Main;

public class ClickManager implements Listener {
	
  @EventHandler
  public void onInt(PlayerInteractEvent e)
  {
    Player p = e.getPlayer();
    if ((e.getAction() == Action.RIGHT_CLICK_BLOCK) && 
      (e.getClickedBlock().getType() == Material.GOLD_BLOCK))
    {
      p.getInventory().addItem(new ItemStack[] { new ItemStack(Material.EXP_BOTTLE, 16) });
      p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast erfolgreich �e16 EXP-Fl�schen �ain dein Inventar bekommen!");
    }
  }
  
  @EventHandler
  public void onInt1(PlayerInteractEvent e)
  {
    Player p = e.getPlayer();
    if ((e.getAction() == Action.RIGHT_CLICK_BLOCK) && 
      (e.getClickedBlock().getType() == Material.LAPIS_BLOCK))
    {
        p.getInventory().addItem(new ItemStack[] { new ItemStack(Material.INK_SACK, 16, (short) 4) });
        p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast erfolgreich �e16 Lapis �ain dein Inventar bekommen!");

    }
  }


  @EventHandler
  public void onPlayerInteract(PlayerInteractEvent event) {
	  Player p = event.getPlayer();
	  ItemStack i = p.getItemInHand();
	  ItemMeta im = i.getItemMeta();
	  ItemStack item = new ItemStack(Material.AIR);

	  
	  if (im.getDisplayName().equalsIgnoreCase("�6Gold Rang")) {
			if (i.getAmount() > 1) {
				p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDu darfst �7'�6Gold Rang�7' �cB�cher nur einzeln einl�sen!");
			} else {
		  p.getInventory().setItemInHand(item);
		  Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "pex user " + p.getName() + " group set Gold");
		  p.kickPlayer("�cDu wurdest vom Server gekickt! \n\n �4�lGrund: �aNeuer Rang \n\n �e�lDein neuer Rang lautet nun: �7'�6Gold�7'");
		  Bukkit.broadcastMessage(Main.instance.cfg.getString("Prefix") + "�aDer Spieler �e" + p.getName() + " �ahat den Rang �7'�6Gold�7' �agewonnen!");
	  }
	  }
 }
}