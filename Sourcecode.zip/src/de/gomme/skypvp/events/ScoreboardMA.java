package de.gomme.skypvp.events;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import de.NeonnBukkit.CoinsAPI.API.CoinsAPI;
import de.gomme.skypvp.main.Main;

public class ScoreboardMA implements Listener

{
	public static void setBoard(Player p) {

		Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
		Objective obj = board.registerNewObjective("aaa", "bbb");

		obj.setDisplayName(Main.instance.cfg.getString("Scoreboard.Title").replaceAll("&", "§").replaceAll("%player%",
				p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		obj.setDisplaySlot(DisplaySlot.SIDEBAR);

		Score a1 = obj.getScore(Main.instance.cfg.getString("Scoreboard.1").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		Score a2 = obj.getScore(Main.instance.cfg.getString("Scoreboard.2").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		Score a3 = obj.getScore("§8» §e" + CoinsAPI.getCoins(p.getUniqueId().toString() + "§e"));
		Score a4 = obj.getScore(Main.instance.cfg.getString("Scoreboard.4").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		Score a5 = obj.getScore(Main.instance.cfg.getString("Scoreboard.5").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		Score a6 = obj.getScore("§8» §e" + Bukkit.getOnlinePlayers().size());
		Score a7 = obj.getScore(Main.instance.cfg.getString("Scoreboard.7").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		Score a8 = obj.getScore(Main.instance.cfg.getString("Scoreboard.8").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		Score a9 = obj.getScore(Main.instance.cfg.getString("Scoreboard.9").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		Score a10 = obj.getScore(Main.instance.cfg.getString("Scoreboard.10").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		Score a11 = obj.getScore(Main.instance.cfg.getString("Scoreboard.11").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		Score a12 = obj.getScore(Main.instance.cfg.getString("Scoreboard.12").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		Score a13 = obj.getScore(Main.instance.cfg.getString("Scoreboard.13").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		Score a14 = obj.getScore(Main.instance.cfg.getString("Scoreboard.14").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		Score a15 = obj.getScore(Main.instance.cfg.getString("Scoreboard.15").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));
		Score a16 = obj.getScore(Main.instance.cfg.getString("Scoreboard.16").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP"))));

		
		// 		Score a1 = obj.getScore(Main.instance.cfg.getString("Scoreboard.1").replaceAll("&", "§").replaceAll("%player%", p.getName().replaceAll("%serverip%", Main.instance.cfg.getString("Links.ServerIP")))));

		a1.setScore(14);
		a2.setScore(13);
		a3.setScore(12);
		a4.setScore(11);
		a5.setScore(10);
		a6.setScore(9);
		a7.setScore(8);
		a8.setScore(7);
		a9.setScore(6);
		a10.setScore(5);
		a11.setScore(4);
		a12.setScore(3);
		a13.setScore(2);
		a14.setScore(1);
		a15.setScore(0);
		a16.setScore(-1);

		p.setScoreboard(board);

		/*
		 * [!] NICHT NACHMACHEN! RAGEN INCOMMING [!]
		 */

		Team owner = board.registerNewTeam("aaa");
		Team admin = board.registerNewTeam("bbb");
		Team developer = board.registerNewTeam("ccc");
		Team srmoderator = board.registerNewTeam("ddd");
		Team moderator = board.registerNewTeam("eee");
		Team supporter = board.registerNewTeam("fff");
		Team builder = board.registerNewTeam("ggg");
		Team youtuber = board.registerNewTeam("hhh");
		Team hero = board.registerNewTeam("jjj");
		Team diamond = board.registerNewTeam("kkk");
		Team gold = board.registerNewTeam("lll");
		Team spieler = board.registerNewTeam("mmm");

		for (Player all : Bukkit.getOnlinePlayers()) {

			if (p.hasPermission(Main.instance.cfg.getString("Tab.Permission1"))) {
				owner.setPrefix(Main.instance.cfg.getString("Tab.1").replaceAll("&", "§"));
				owner.addPlayer(all);
			} else if (p.hasPermission(Main.instance.cfg.getString("Tab.Permission2"))) {
				admin.setPrefix(Main.instance.cfg.getString("Tab.2").replaceAll("&", "§"));
				admin.addPlayer(all);
			} else if (p.hasPermission(Main.instance.cfg.getString("Tab.Permission3"))) {
				developer.setPrefix(Main.instance.cfg.getString("Tab.3").replaceAll("&", "§"));
				developer.addPlayer(all);
			} else if (p.hasPermission(Main.instance.cfg.getString("Tab.Permission4"))) {
				srmoderator.setPrefix(Main.instance.cfg.getString("Tab.4").replaceAll("&", "§"));
				srmoderator.addPlayer(all);
			} else if (p.hasPermission(Main.instance.cfg.getString("Tab.Permission5"))) {
				moderator.setPrefix(Main.instance.cfg.getString("Tab.5").replaceAll("&", "§"));
				moderator.addPlayer(all);
			} else if (p.hasPermission(Main.instance.cfg.getString("Tab.Permission6"))) {
				supporter.setPrefix(Main.instance.cfg.getString("Tab.6").replaceAll("&", "§"));
				supporter.addPlayer(all);
			} else if (p.hasPermission(Main.instance.cfg.getString("Tab.Permission7"))) {
				builder.setPrefix(Main.instance.cfg.getString("Tab.7").replaceAll("&", "§"));
				builder.addPlayer(all);
			} else if (p.hasPermission(Main.instance.cfg.getString("Tab.Permission8"))) {
				youtuber.setPrefix(Main.instance.cfg.getString("Tab.8").replaceAll("&", "§"));
				youtuber.addPlayer(all);
			} else if (p.hasPermission(Main.instance.cfg.getString("Tab.Permission9"))) {
				hero.setPrefix(Main.instance.cfg.getString("Tab.9").replaceAll("&", "§"));
				hero.addPlayer(all);
			} else if (p.hasPermission(Main.instance.cfg.getString("Tab.Permission10"))) {
				diamond.setPrefix(Main.instance.cfg.getString("Tab.10").replaceAll("&", "§"));
				diamond.addPlayer(all);
			} else if (p.hasPermission(Main.instance.cfg.getString("Tab.Permission11"))) {
				gold.setPrefix(Main.instance.cfg.getString("Tab.11").replaceAll("&", "§"));
				gold.addPlayer(all);
			} else {
				spieler.setPrefix(Main.instance.cfg.getString("Tab.12").replaceAll("&", "§"));
				spieler.addPlayer(all);
			}
		}

	}

	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		setBoard(e.getPlayer());


	}
}
