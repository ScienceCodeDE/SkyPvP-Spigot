package de.gomme.skypvp.events;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ColorCodes implements Listener {

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onC(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        if(p.hasPermission("chatcolor.use")) {
        	e.setMessage(ChatColor.translateAlternateColorCodes('&', e.getMessage()));
        }
    }
}
