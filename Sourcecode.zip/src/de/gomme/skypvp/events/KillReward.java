package de.gomme.skypvp.events;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

import de.NeonnBukkit.CoinsAPI.API.CoinsAPI;
import de.gomme.skypvp.main.Main;
import de.gomme.skypvp.utils.Stats;

public class KillReward
  implements Listener
{
		
  @EventHandler
  public void onDeath(PlayerDeathEvent e)
  {	  
    Player p = e.getEntity();
    
    Player k = p.getKiller();
    
	Stats stats = new Stats(k);

    if ((k instanceof Player))
    {
    	Bukkit.broadcastMessage(Main.instance.cfg.getString("Prefix") + "�aDer Spieler �e" + p.getName() + " �awurde von �c" + k.getName() + " �aget�tet�8!");
    	Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "coins " + k.getName() + " addcoins 100");
      k.playSound(k.getLocation(), Sound.LEVEL_UP, 15.0F, 15.0F);
      stats.addKill();
    }
    if (k == null)
    {
      p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDu bist gestorben!");
      
    }
    else
    {
      p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDu wurdest von �e" + k.getDisplayName() + " �c get�tet�8!");
      k.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast �e" + p.getDisplayName() + " �aget�tet�8!");
      k.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast �e100 Coins �aals Belohnung erhalten�8.");
     
    }
  }
}
