package de.gomme.skypvp.events;

import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class OnDamage implements Listener {

	@EventHandler
	public void onEntityDamage(EntityDamageByEntityEvent event) {

		if ((event.getCause().equals(DamageCause.ENTITY_ATTACK) && (event.getDamager() instanceof Player) && (event.getEntity() instanceof Villager))) {
			event.setCancelled(true);

		}
	}

}
