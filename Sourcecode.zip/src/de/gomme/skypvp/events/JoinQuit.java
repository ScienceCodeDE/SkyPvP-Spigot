package de.gomme.skypvp.events;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import de.gomme.skypvp.main.Main;

public class JoinQuit implements Listener {
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {

		Player p = e.getPlayer();
		if(p.hasPermission("skypvp.team")) {
		e.setJoinMessage(Main.instance.cfg.getString("Prefix") + "�aDas Teammitglied �e" + p.getName() + " �ahat den Server betreten!");
		p.performCommand("spawn");
		} else {
			e.setJoinMessage(Main.instance.cfg.getString("Prefix") + "�e" + p.getDisplayName() + " �ahat dem Server beigetreten.");
			p.playSound(p.getLocation(), Sound.CLICK, 3, 1);
			p.performCommand("spawn");
		}

	}

	@EventHandler
	public void onQuit(PlayerQuitEvent e) {

		Player p = e.getPlayer();
		if(p.hasPermission("skypvp.team")) {
			e.setQuitMessage(Main.instance.cfg.getString("Prefix") + "�aDas Teammitglied �e" + p.getName() + " �ahat den Server verlassen!");

		}

		e.setQuitMessage(Main.instance.cfg.getString("Prefix") + "�e " + p.getName() + " �ahat den Server verlassen.");

	}

}