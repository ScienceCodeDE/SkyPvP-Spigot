package de.gomme.skypvp.crates;

import java.util.ArrayList;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import de.gomme.skypvp.utils.Drops;
import de.gomme.skypvp.utils.Items;

public class Crates {

	public static ArrayList<Player> list = new ArrayList<Player>();

	public static void openInventory(Player p, CrateType ct) {

		if (ct == CrateType.Normale_Crate) {
			Inventory inv = Bukkit.createInventory(null, 9 * 6, "�7� �eNormale Crate �7�");

			for (int i = 0; i < 9 * 6; i++) {
				inv.setItem(i, Drops.createItem(Material.STAINED_GLASS_PANE, "�e???"));
			}

			p.openInventory(inv);
			p.playSound(p.getLocation(), Sound.LEVEL_UP, 3, 3);
		}
		if (ct == CrateType.Seltene_Crate) {
			Inventory inv = Bukkit.createInventory(null, 9 * 6, "�7� �6Seltene Crate �7�");

			for (int i = 0; i < 9 * 6; i++) {
				inv.setItem(i, Drops.createItem(Material.STAINED_GLASS_PANE, "�e???"));
			}

			p.openInventory(inv);
			p.playSound(p.getLocation(), Sound.LEVEL_UP, 3, 3);
		}
		if (ct == CrateType.Epische_Crate) {
			Inventory inv = Bukkit.createInventory(null, 9 * 6, "�7� �bEpische Crate �7�");

			for (int i = 0; i < 9 * 6; i++) {
				inv.setItem(i, Drops.createItem(Material.STAINED_GLASS_PANE, "�e???"));
			}

			p.openInventory(inv);
			p.playSound(p.getLocation(), Sound.LEVEL_UP, 3, 3);
		}
		if (ct == CrateType.Legend�re_Crate) {
			Inventory inv = Bukkit.createInventory(null, 9 * 6, "�7� �aLegend�re Crate �7�");

			for (int i = 0; i < 9 * 6; i++) {
				inv.setItem(i, Drops.createItem(Material.STAINED_GLASS_PANE, "�e???"));
			}

			p.openInventory(inv);
			p.playSound(p.getLocation(), Sound.LEVEL_UP, 3, 3);
		}
	}

	@SuppressWarnings("deprecation")
	public static ItemStack createItem(int type, int anzahl, String dis) {
		ItemStack i = new ItemStack(type, anzahl);
		ItemMeta m = i.getItemMeta();
		m.setDisplayName(dis);
		i.setItemMeta(m);
		return i;
	}

	public static ItemStack createItem(Material mat, int anzahl, String dis) {
		ItemStack i = new ItemStack(mat, anzahl);
		ItemMeta m = i.getItemMeta();
		m.setDisplayName(dis);
		i.setItemMeta(m);
		return i;
	}

	public static ItemStack giveCrate(CrateType type, int anzahl) {
		if (type == CrateType.Normale_Crate) {
			return Crates.createSkull(anzahl, "�7� �eNormale Crate �7�", "MHF_Chest");
		} else if (type == CrateType.Seltene_Crate) {
			return Crates.createSkull(anzahl, "�7� �6Seltene Crate �7�", "MHF_Chest");
		} else if (type == CrateType.Epische_Crate) {
			return Crates.createSkull(anzahl, "�7� �bEpische Crate �7�", "MHF_Chest");
		} else if (type == CrateType.Legend�re_Crate) {
			return Crates.createSkull(anzahl, "�7� �aLegend�re Crate �7�", "MHF_Chest");
		} else {
			return null;
		}
	}

	public static void openAdminInv(Player p) {
		Inventory inv = Bukkit.createInventory(null, 9, "�4Admin �cCrates");
		inv.setItem(1, Crates.createSkull(64, "�7� �eNormale Crate �7�", "MHF_Chest"));
		inv.setItem(3, Crates.createSkull(64, "�7� �6Seltene Crate �7�", "MHF_Chest"));
		inv.setItem(5, Crates.createSkull(64, "�7� �bEpische Crate �7�", "MHF_Chest"));
		inv.setItem(7, Crates.createSkull(64, "�7� �aLegend�re Crate �7�", "MHF_Chest"));
		p.openInventory(inv);
	}

	public static ItemStack createSkull(int anzahl, String dis, String name) {
		ItemStack itemStack = new ItemStack(Material.SKULL_ITEM, anzahl, (short) 3);
		SkullMeta meta = (SkullMeta) itemStack.getItemMeta();
		meta.setOwner(name);
		meta.setDisplayName(dis);
		itemStack.setItemMeta(meta);
		return itemStack;
	}

	public static ItemStack getUltraCrate() {
		Random r = new Random();
		int i = r.nextInt(12);

		switch (i) {
		case 0:
			return new ItemStack(Material.DIAMOND, 19);
		case 1:
			return new ItemStack(Material.EMERALD, 22);
		case 2:
			return new ItemStack(Material.DRAGON_EGG, 13);
		case 3:
			return Items.createEnchantmentItem(Material.DIAMOND_SWORD, 1, 0, "�aEpisches Schwert", Enchantment.DAMAGE_ALL, 11);
		case 4:
			return new ItemStack(Material.GOLDEN_APPLE, 5, (short)1);
		case 5:
			return createItem(Material.YELLOW_FLOWER, 1, "�61000 Coins");
		case 6:
			return new ItemStack(Material.MONSTER_EGG, 1, (short) 94);
		case 7:
			return new ItemStack(Material.IRON_INGOT, 16);
		case 8:
			return createItem(Material.BOOK, 1, "�6Gold Rang");
		case 9:
			return Items.createEnchantmentItem(Material.IRON_CHESTPLATE, 1, 0, "�aEpische Brustplatte", Enchantment.PROTECTION_PROJECTILE, 2);
		case 10:
			return createItem(Material.YELLOW_FLOWER, 1, "�6500 Coins");
		default:
			return new ItemStack(Material.ROTTEN_FLESH);
		}
	}

	public static ItemStack getChampionCrate() {
		Random r = new Random();
		int i = r.nextInt(11);

		switch (i) {
		case 0:
			return new ItemStack(Material.DIAMOND_BLOCK, 18);
		case 1:
			return new ItemStack(Material.GOLDEN_APPLE, 5, (short)1);
		case 2:
			return Items.createEnchantmentItem(Material.DIAMOND_SWORD, 1, 0, "�aLegend�res Schwert", Enchantment.DAMAGE_ALL, 15);
		case 3:
			return createItem(Material.YELLOW_FLOWER, 1, "�61000 Coins");
		case 4:
			return Items.createEnchantmentItem(Material.DIAMOND_LEGGINGS, 1, 0, "�aLegend�re Hose", Enchantment.PROTECTION_ENVIRONMENTAL, 5);
		case 5:
			return Items.createEnchantmentItem(Material.STICK, 1, 0, "�aLegend�rer Stick", Enchantment.KNOCKBACK, 13);
		case 6:
			return new ItemStack(Material.IRON_INGOT, 32);
		case 7:
			return createItem(Material.BOOK, 1, "�6Gold Rang");
		case 8:
			return createItem(Material.YELLOW_FLOWER, 1, "�6500 Coins");
		case 9:
			return new ItemStack(Material.IRON_SWORD);
		default:
			return new ItemStack(Material.ROTTEN_FLESH);
		}
	}

}