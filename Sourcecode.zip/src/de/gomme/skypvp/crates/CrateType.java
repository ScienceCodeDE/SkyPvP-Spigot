package de.gomme.skypvp.crates;

public enum CrateType {
	
	Normale_Crate,
	Seltene_Crate,
	Epische_Crate,
	Legend�re_Crate;

}