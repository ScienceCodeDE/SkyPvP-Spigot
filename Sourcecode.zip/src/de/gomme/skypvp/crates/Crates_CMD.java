package de.gomme.skypvp.crates;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.gomme.skypvp.main.Main;

public class Crates_CMD implements CommandExecutor {
	
	private Main plugin;
	
	

	public Crates_CMD(Main main) {
		this.plugin = main;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command arg1, String arg2, String[] args) {
		if(sender instanceof Player) {
			Player p = (Player)sender;
			if(p.hasPermission("skypvp.crates")) {
				
				Crates.openAdminInv(p);
				
			} else {
				p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDazu hast du keine Rechte!");
			}
		}
		return true;
	}

}