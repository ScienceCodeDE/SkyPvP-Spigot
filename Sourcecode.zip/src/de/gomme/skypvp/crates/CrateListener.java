package de.gomme.skypvp.crates;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.CommandException;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import de.gomme.skypvp.utils.Drops;
import de.gomme.skypvp.utils.Items;
import de.gomme.skypvp.main.Main;

public class CrateListener implements Listener {

	private Main plugin;

	public static int amount = 0;

	public CrateListener(Main main) {
		this.plugin = main;
		this.plugin.getServer().getPluginManager().registerEvents(this, plugin);
	}

	@EventHandler
	public void onCrate(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		String dis = e.getItem().getItemMeta().getDisplayName();
		if (e.getAction() == Action.RIGHT_CLICK_AIR) {
			e.setCancelled(false);
				if (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase("�7� �eNormale Crate �7�")) {
					Crates.openInventory(p, CrateType.Normale_Crate);
					Crates.list.add(p);
					removeItem(p, createSkull(dis, "MHF_Chest"), p.getItemInHand().getType(), dis, plugin);
					p.updateInventory();
				} else if (dis.equalsIgnoreCase("�7� �6Seltene Crate �7�")) {
					Crates.openInventory(p, CrateType.Seltene_Crate);
					Crates.list.add(p);
					removeItem(p, createSkull(dis, "MHF_Chest"), p.getItemInHand().getType(), dis, plugin);
					p.updateInventory();
				} else if (dis.equalsIgnoreCase("�7� �bEpische Crate �7�")) {
					Crates.openInventory(p, CrateType.Epische_Crate);
					Crates.list.add(p);
					removeItem(p, createSkull(dis, "MHF_Chest"), p.getItemInHand().getType(), dis, plugin);
					p.updateInventory();
				} else if (dis.equalsIgnoreCase("�7� �aLegend�re Crate �7�")) {
					Crates.openInventory(p, CrateType.Legend�re_Crate);
					Crates.list.add(p);
					removeItem(p, createSkull(dis, "MHF_Chest"), p.getItemInHand().getType(), dis, plugin);
				}

		} else if (e.getAction() == Action.RIGHT_CLICK_BLOCK && isCrate(e.getItem())) {
			e.setCancelled(true);
			p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cDu darfst keine Crates platzieren!");

		} else if (e.getAction() == Action.LEFT_CLICK_AIR || e.getAction() == Action.LEFT_CLICK_BLOCK) {
			try {

				if (e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase("�7� �eNormale Crate �7�")) {
					Inventory inv = Bukkit.createInventory(null, 9 * 3, "�6�lDu kannst gewinnen:");
					inv.setItem(0, new ItemStack(Material.DIAMOND));
					inv.setItem(1, new ItemStack(Material.DIAMOND_SWORD));
					inv.setItem(2, new ItemStack(Material.ENDER_PEARL, 16));
					inv.setItem(3, new ItemStack(Material.GOLDEN_APPLE, 5));
					inv.setItem(4, new ItemStack(Material.GOLD_INGOT, 12));
					inv.setItem(5, new ItemStack(Material.BEACON));
					inv.setItem(6, new ItemStack(Material.IRON_CHESTPLATE));
					inv.setItem(7, new ItemStack(Material.IRON_INGOT, 8));
					inv.setItem(8, new ItemStack(Material.ANVIL));
					inv.setItem(9, new ItemStack(Material.STONE_PICKAXE));
					inv.setItem(10, new ItemStack(Material.CARROT_ITEM));
					p.openInventory(inv);
				} else if (dis.equalsIgnoreCase("�7� �6Seltene Crate �7�")) {
					Inventory inv = Bukkit.createInventory(null, 9 * 3, "�6�lDu kannst gewinnen:");
					inv.setItem(0, new ItemStack(Material.DIAMOND, 4));
					inv.setItem(1, new ItemStack(Material.EMERALD, 4));
					inv.setItem(2, new ItemStack(Material.DIAMOND_PICKAXE));
					inv.setItem(3, new ItemStack(Material.GOLDEN_APPLE, 12));
					inv.setItem(4, new ItemStack(Material.DIAMOND_LEGGINGS));
					inv.setItem(5, new ItemStack(Material.MOB_SPAWNER));
					inv.setItem(6, new ItemStack(Material.IRON_INGOT, 16));
					inv.setItem(7, new ItemStack(Material.DRAGON_EGG, 1));
					inv.setItem(8, new ItemStack(Material.MONSTER_EGG, 2));
					p.openInventory(inv);
				} else if (dis.equalsIgnoreCase("�7� �bEpische Crate �7�")) {
					Inventory inv = Bukkit.createInventory(null, 9 * 3, "�6�lDu kannst gewinnen:");
					inv.setItem(0, new ItemStack(Material.DIAMOND_BLOCK, 19));
					inv.setItem(1, new ItemStack(Material.EMERALD, 22));
					inv.setItem(2, new ItemStack(Material.DRAGON_EGG, 13));
					inv.setItem(3, Items.createEnchantmentItem(Material.DIAMOND_SWORD, 1, 0, "�aEpisches Schwert", Enchantment.DAMAGE_ALL, 11));
					inv.setItem(4, new ItemStack(Material.GOLDEN_APPLE));
					inv.setItem(5, Crates.createItem(Material.YELLOW_FLOWER, 1, "�61000 Coins"));
					inv.setItem(6, new ItemStack(Material.MONSTER_EGG, 1, (short) 94));
					inv.setItem(7, new ItemStack(Material.IRON_INGOT, 16));
					inv.setItem(8, Items.createEnchantmentItem(Material.IRON_CHESTPLATE, 1, 0, "�aEpische Brustplatte", Enchantment.PROTECTION_PROJECTILE, 1));
					inv.setItem(9, Crates.createItem(Material.YELLOW_FLOWER, 1, "�6500 Coins"));
					inv.setItem(10, Crates.createItem(Material.BOOK, 1, "�6Gold Rang"));

					p.openInventory(inv);
				} else if (dis.equalsIgnoreCase("�7� �aLegend�re Crate �7�")) {
					Inventory inv = Bukkit.createInventory(null, 9 * 3, "�6�lDu kannst gewinnen:");
					inv.setItem(0, new ItemStack(Material.DIAMOND_BLOCK, 32));
					inv.setItem(1, new ItemStack(Material.GOLDEN_APPLE, 5, (short)1));
					inv.setItem(2, Items.createEnchantmentItem(Material.DIAMOND_SWORD, 1, 0, "�aLegend�res Schwert", Enchantment.DAMAGE_ALL, 15));
					inv.setItem(3, Crates.createItem(Material.YELLOW_FLOWER, 1, "�61000 Coins"));
					inv.setItem(4, Items.createEnchantmentItem(Material.DIAMOND_LEGGINGS, 1, 0, "�aLegend�re Hose", Enchantment.PROTECTION_ENVIRONMENTAL, 5));
					inv.setItem(5, Items.createEnchantmentItem(Material.STICK, 1, 0, "�aLegend�rer Stick", Enchantment.KNOCKBACK, 13));
					inv.setItem(6, new ItemStack(Material.IRON_INGOT, 32));
					inv.setItem(7, Crates.createItem(Material.BOOK, 1, "�6Gold Rang"));
					inv.setItem(8, Crates.createItem(Material.YELLOW_FLOWER, 1, "�6500 Coins"));
					inv.setItem(9, new ItemStack(Material.IRON_SWORD));
					p.openInventory(inv);
				}

			} catch (NullPointerException ignored) {

			}
		}
	}
		
	

	private boolean isCrate(ItemStack i) {
		try {
			if (i.getItemMeta().getDisplayName().equalsIgnoreCase("�7� �eNormale Crate �7�")
					|| i.getItemMeta().getDisplayName().equalsIgnoreCase("�7� �6Seltene Crate �7�")
					|| i.getItemMeta().getDisplayName().equalsIgnoreCase("�7� �bEpische Crate �7�")
					|| i.getItemMeta().getDisplayName().equalsIgnoreCase("�7� �aLegend�re Crate �7�")) {
				return true;
			} else {
				return false;
			}
		} catch (NullPointerException ignored) {
			return false;
		}
	}

	private static ItemStack createSkull(int anzahl, String dis, String name) {
		ItemStack itemStack = new ItemStack(Material.SKULL_ITEM, anzahl, (short) 3);
		SkullMeta meta = (SkullMeta) itemStack.getItemMeta();
		meta.setOwner(name);
		meta.setDisplayName(dis);
		itemStack.setItemMeta(meta);
		return itemStack;
	}

	private static ItemStack createSkull(String dis, String name) {
		ItemStack itemStack = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
		SkullMeta meta = (SkullMeta) itemStack.getItemMeta();
		meta.setOwner(name);
		meta.setDisplayName(dis);
		itemStack.setItemMeta(meta);
		return itemStack;
	}

	private void removeItem(Player p, ItemStack createSkull, Material type, String dis, Main plugin2) {
		ItemStack item = p.getInventory().getItemInHand();
		if (item.getAmount() > 1) {
			p.closeInventory();
			p.sendMessage(Main.instance.cfg.getString("Prefix") + "�cBitte stacke keine Crates!");
		}
		else item = new ItemStack(Material.AIR);
		p.getInventory().setItemInHand(item);
	}
	

	

	@EventHandler
	public void onClick(InventoryClickEvent e) {
		if (e.getInventory().getName().contains("Crate")
				&& !e.getInventory().getName().equalsIgnoreCase("�4Admin �cCrates")) {
			e.setCancelled(true);
			Player p = (Player) e.getWhoClicked();
			if (Crates.list.contains(p)) {
				try {
					if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�e???")) {

						int i = e.getSlot();
						if (e.getInventory().getName().equalsIgnoreCase("�7� �eNormale Crate �7�")) {
							ItemStack is = Drops.getRandomLowDrop();
							e.getInventory().setItem(i, is);
							sendWinMessage(is, p);
							p.playSound(p.getLocation(), Sound.FIREWORK_LAUNCH, 3, 3);
							p.getInventory().addItem(is);
							Crates.list.remove(p);
							e.getInventory().remove(Material.STAINED_GLASS_PANE);
						} else if (e.getInventory().getName().equalsIgnoreCase("�7� �6Seltene Crate �7�")) {
							ItemStack is = Drops.getRandomUltraDrop();
							e.getInventory().setItem(i, is);
							sendWinMessage(is, p);
							p.playSound(p.getLocation(), Sound.FIREWORK_LAUNCH, 3, 3);
							p.getInventory().addItem(is);
							Crates.list.remove(p);
							e.getInventory().remove(Material.STAINED_GLASS_PANE);
						} else if (e.getInventory().getName().equalsIgnoreCase("�7� �bEpische Crate �7�")) {
							ItemStack is = Crates.getChampionCrate();
							try {
								if (is.getItemMeta().getDisplayName().equalsIgnoreCase("�6500 Coins")) {
									p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast �e500 Coins �agewonnen!");
									e.getInventory().setItem(i, is);
									Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
											"coins " + p.getName() + " addcoins 500");
								} else if (is.getItemMeta().getDisplayName().equalsIgnoreCase("�61000 Coins")) {
									p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast �e1000 Coins �agewonnen!");
									e.getInventory().setItem(i, is);
									Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
											"coins " + p.getName() + " addcoins 1000");
									
									sendWinMessage(is, p);
									p.playSound(p.getLocation(), Sound.FIREWORK_LAUNCH, 3, 3);
									p.getInventory().addItem(is);
								}
							} catch (CommandException | NullPointerException ignored) {
								sendWinMessage(is, p);
								p.playSound(p.getLocation(), Sound.FIREWORK_LAUNCH, 3, 3);
								p.getInventory().addItem(is);
							}
							e.getInventory().setItem(i, is);
							Crates.list.remove(p);
							e.getInventory().remove(Material.STAINED_GLASS_PANE);
						} else if (e.getInventory().getName().equalsIgnoreCase("�7� �aLegend�re Crate �7�")) {
							ItemStack is = Crates.getChampionCrate();
							try {
								if (is.getItemMeta().getDisplayName().equalsIgnoreCase("�6500 Coins")) {
									p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast �e500 Coins �agewonnen!");
									e.getInventory().setItem(i, is);
									Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
											"coins " + p.getName() + " addcoins 500");
								} else if (is.getItemMeta().getDisplayName().equalsIgnoreCase("�61000 Coins")) {
									p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast �e1000 Coins �agewonnen!");
									e.getInventory().setItem(i, is);
									Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
											"coins " + p.getName() + " addcoins 1000");
									
								} else {
									sendWinMessage(is, p);
									p.playSound(p.getLocation(), Sound.FIREWORK_LAUNCH, 3, 3);
									p.getInventory().addItem(is);
								}
							} catch (CommandException | NullPointerException ignored) {
								sendWinMessage(is, p);
								p.playSound(p.getLocation(), Sound.FIREWORK_LAUNCH, 3, 3);
								p.getInventory().addItem(is);
							}
							e.getInventory().setItem(i, is);
							Crates.list.remove(p);
							e.getInventory().remove(Material.STAINED_GLASS_PANE);
						}
					}
				} catch (NullPointerException ignored) {

				}
			}
		} else if (e.getInventory().getName().equalsIgnoreCase("�6�lDu kannst gewinnen:")) {
			e.setCancelled(true);
		}
	}

	public static void sendWinMessage(ItemStack is, Player p) {
		if (is != null && is.getItemMeta().getDisplayName() != null) {
			p.sendMessage(Main.instance.cfg.getString("Prefix") + "�aDu hast �6" + is.getItemMeta().getDisplayName() + " �agewonnen!");
		}
	}

}
