package de.gomme.skypvp.main;

import de.NeonnBukkit.CoinsAPI.API.CoinsAPI;
import de.gomme.skypvp.commands.Admin;
import de.gomme.skypvp.commands.Broadcast;
import de.gomme.skypvp.commands.Build;
import de.gomme.skypvp.commands.ChatClear;
import de.gomme.skypvp.commands.Clear;
import de.gomme.skypvp.commands.CreateUmfrage;
import de.gomme.skypvp.commands.DeleteUmfrage;
import de.gomme.skypvp.commands.DropEvent;
import de.gomme.skypvp.commands.EnderChest;
import de.gomme.skypvp.commands.Feed;
import de.gomme.skypvp.commands.Fix;
import de.gomme.skypvp.commands.Fly;
import de.gomme.skypvp.commands.Forum;
import de.gomme.skypvp.commands.GM;
import de.gomme.skypvp.commands.GiveAll;
import de.gomme.skypvp.commands.Head;
import de.gomme.skypvp.commands.Heal;
import de.gomme.skypvp.commands.Kick;
import de.gomme.skypvp.commands.KickAll;
import de.gomme.skypvp.commands.Kill;
import de.gomme.skypvp.commands.List;
import de.gomme.skypvp.commands.Perk;
import de.gomme.skypvp.commands.Ping;
import de.gomme.skypvp.commands.Rang;
import de.gomme.skypvp.commands.Repair;
import de.gomme.skypvp.commands.Restart;
import de.gomme.skypvp.commands.RestartWarnung;
import de.gomme.skypvp.commands.SetSpawn;
import de.gomme.skypvp.commands.Shop;
import de.gomme.skypvp.commands.SpawnShop;
import de.gomme.skypvp.commands.StatsCMD;
import de.gomme.skypvp.commands.Sun;
import de.gomme.skypvp.commands.Support;
import de.gomme.skypvp.commands.Tag;
import de.gomme.skypvp.commands.TeamSpeak;
import de.gomme.skypvp.commands.Trash;
import de.gomme.skypvp.commands.Troll;
import de.gomme.skypvp.commands.Umfrage;
import de.gomme.skypvp.commands.Vanish;
import de.gomme.skypvp.commands.Verlosung;
import de.gomme.skypvp.commands.Vote;
import de.gomme.skypvp.commands.Website;
import de.gomme.skypvp.commands.WorkBench;
import de.gomme.skypvp.commands.YouTuber;
import de.gomme.skypvp.crates.CrateListener;
import de.gomme.skypvp.crates.Crates_CMD;
import de.gomme.skypvp.crates.GiveCrates;
import de.gomme.skypvp.events.BauEvent;
import de.gomme.skypvp.events.BlockCommand;
import de.gomme.skypvp.events.ChatFormat;
import de.gomme.skypvp.events.ClickManager;
import de.gomme.skypvp.events.ColorCodes;
import de.gomme.skypvp.events.DeathEvent;
import de.gomme.skypvp.events.DeathHigh;
import de.gomme.skypvp.events.FallDamage;
import de.gomme.skypvp.events.JoinQuit;
import de.gomme.skypvp.events.KillReward;
import de.gomme.skypvp.events.Notfall;
import de.gomme.skypvp.events.OnDamage;
import de.gomme.skypvp.events.ClickTest;
import de.gomme.skypvp.events.OnJoin;
import de.gomme.skypvp.events.ScoreboardMA;
import de.gomme.skypvp.events.TeamChat;
import de.gomme.skypvp.kits.Kits;
import de.gomme.skypvp.reportsystem.Filter;
import de.gomme.skypvp.reportsystem.Report;
import de.gomme.skypvp.reportsystem.Spectate;
import de.gomme.skypvp.shop.BuyItems;
import de.gomme.skypvp.utils.MySQL;
import de.gomme.skypvp.utils.UmfrageManager;

import java.lang.reflect.Field;

import net.minecraft.server.v1_8_R3.IChatBaseComponent;
import net.minecraft.server.v1_8_R3.IChatBaseComponent.ChatSerializer;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerListHeaderFooter;
import net.minecraft.server.v1_8_R3.PlayerConnection;

import java.io.File;
import java.io.IOException;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent.Result;
import org.bukkit.event.server.ServerListPingEvent;
import org.bukkit.plugin.java.JavaPlugin;

/*
 * Plugin by ScienceCode
 * 
 * Version: 3.0
 * 
 * Last Update: 15.04.2018
 * Copright (C) 2018 - ScienceCode
 * You are not allowed to see this Source
 * You are not allowed to sell it
 * You are not allowed to say it is your's Plugin
 * You are not allowed to upload it
 * You are not allowed to edit the SRC
 * You are not allowed to do something with the Code
 * You are not allowed to remove this copright notice
 * You are not allowed to say you are "ScienceCode"
 * You are not allowed to send it
 */

/*
 * TODO: Nothing.
 */

@SuppressWarnings("unused")
public class Main extends JavaPlugin implements Listener {
	
	public FileConfiguration cfg = getConfig();
	public static Main instance;
	public static MySQL mysql;
	public File path;

	public static boolean wartung = false;

	public void onEnable() {
		
		getCommand("build").setExecutor(new Build());
		getCommand("clear").setExecutor(new Clear());
		getCommand("dropevent").setExecutor(new DropEvent());
		getCommand("feed").setExecutor(new Feed());
		getCommand("heal").setExecutor(new Heal());
		getCommand("kill").setExecutor(new Kill());
		getCommand("ping").setExecutor(new Ping());
		getCommand("restart").setExecutor(new Restart());
		getCommand("restartinfo").setExecutor(new RestartWarnung());
		getCommand("spawn").setExecutor(new SetSpawn());
		getCommand("setspawn").setExecutor(new SetSpawn());
		getCommand("trash").setExecutor(new Trash());
		getCommand("admin").setExecutor(new Admin());
		getCommand("giveall").setExecutor(new GiveAll());
		getCommand("ec").setExecutor(new EnderChest());
		getCommand("kick").setExecutor(new Kick());
		getCommand("wb").setExecutor(new WorkBench());
		getCommand("rang").setExecutor(new Rang());
		getCommand("shop").setExecutor(new Shop());
		getCommand("gamemode").setExecutor(new GM());
		getCommand("fly").setExecutor(new Fly());
		getCommand("vanish").setExecutor(new Vanish());
		getCommand("chatclear").setExecutor(new ChatClear());
		getCommand("spawnshop").setExecutor(new SpawnShop());
		getCommand("repair").setExecutor(new Repair());
		getCommand("sun").setExecutor(new Sun());
		getCommand("tag").setExecutor(new Tag());
		getCommand("youtuber").setExecutor(new YouTuber());
		getCommand("givecrates").setExecutor(new GiveCrates(this));
		getCommand("crates").setExecutor(new Crates_CMD(this));
		getCommand("head").setExecutor(new Head());
		getCommand("teamspeak").setExecutor(new TeamSpeak());
		getCommand("webseite").setExecutor(new Website());
		getCommand("forum").setExecutor(new Forum());
		getCommand("verlosung").setExecutor(new Verlosung());
		getCommand("umfrage").setExecutor(new Umfrage());
		getCommand("createumfrage").setExecutor(new CreateUmfrage());
		getCommand("deleteumfrage").setExecutor(new DeleteUmfrage());
		getCommand("stats").setExecutor(new StatsCMD());
		getCommand("report").setExecutor(new Report());
		getCommand("fix").setExecutor(new Fix());
		getCommand("list").setExecutor(new List());
		getCommand("spectate").setExecutor(new Spectate());
		getCommand("kickall").setExecutor(new KickAll());
		getCommand("troll").setExecutor(new Troll());
		getCommand("broadcast").setExecutor(new Broadcast());
		getCommand("kits").setExecutor(new Kits());
		getCommand("support").setExecutor(new Support());
		getCommand("vote").setExecutor(new Vote());
		getCommand("perks").setExecutor(new Perk());

		getServer().getPluginManager().registerEvents(new BauEvent(), this);
		getServer().getPluginManager().registerEvents(new ColorCodes(), this);
		getServer().getPluginManager().registerEvents(new OnJoin(), this);
		getServer().getPluginManager().registerEvents(new TeamChat(), this);
		getServer().getPluginManager().registerEvents(new Shop(), this);
		getServer().getPluginManager().registerEvents(new ClickManager(), this);
		getServer().getPluginManager().registerEvents(new BlockCommand(), this);
		getServer().getPluginManager().registerEvents(new JoinQuit(), this);
		getServer().getPluginManager().registerEvents(new de.gomme.skypvp.shop.Shop(), this);
		getServer().getPluginManager().registerEvents(new BuyItems(), this);
		getServer().getPluginManager().registerEvents(new Shop(), this);
		getServer().getPluginManager().registerEvents(new KillReward(), this);
		getServer().getPluginManager().registerEvents(new FallDamage(this), this);
		getServer().getPluginManager().registerEvents(new ClickTest(), this);
		getServer().getPluginManager().registerEvents(new CrateListener(this), this);
		getServer().getPluginManager().registerEvents(new Kill(), this);
		getServer().getPluginManager().registerEvents(new OnDamage(), this);
		getServer().getPluginManager().registerEvents(new DeathEvent(), this);
		getServer().getPluginManager().registerEvents(new Filter(), this);
		getServer().getPluginManager().registerEvents(new DeathHigh(), this);
		getServer().getPluginManager().registerEvents(new Notfall(), this);
		getServer().getPluginManager().registerEvents(new ChatFormat(), this);
		getServer().getPluginManager().registerEvents(new Kits(), this);
		getServer().getPluginManager().registerEvents(new ScoreboardMA(), this);
		getServer().getPluginManager().registerEvents(new Perk(), this);

		Bukkit.getPluginManager().registerEvents(this, this);
		
		setupConfig();
	}
		
		public void setupConfig() {
		
			instance = this;
						
		path = getDataFolder();
		if (!getConfig().contains("MySQL")) {
			try {
			getConfig().options().header("Plugin by ScienceCode | Copright (C) 2018 - ScienceCode | Placeholders: %player% - Spieler / %serverip% - Die Server IP/Domain / Ideen?");
			getConfig().getBoolean("Wartung.Status", false);
			getConfig().getBoolean("Stats.Status", false);
			getConfig().set("Prefix", "§eSkyPvP §8| ");
			getConfig().set("Notfall.Name", "IBims1NameVomOwner");
			getConfig().set("MySQL.ip", "000.000.000");
			getConfig().set("MySQL.database", "StatsAPI");
			getConfig().set("MySQL.name", "Benutzer");
			getConfig().set("MySQL.password", "IBims1PW");
			getConfig().set("Links.TS", "&eDeinServer.de");
			getConfig().set("Links.Forum", "&ehttp://DeinServer.de/");
			getConfig().set("Links.Website", "&ehttp://DeinServer.de/");
			getConfig().set("Links.Support", "&ehttp://DeinServer.de/");
			getConfig().set("Links.ServerIP", "&eDeinServer.de");
			getConfig().set("Links.Vote", "&ehttp://DeinServer.de/vote.html");
			getConfig().set("CookieClicker.Name", "QuadratCookie");
			getConfig().set("TeamChat.Command", "@t");
			getConfig().set("Scoreboard.Title", "&8» &eDeinServer &8«");
			getConfig().set("Scoreboard.1", "&0");
			getConfig().set("Scoreboard.2", "&7Coins:");
			getConfig().set("Scoreboard.3", " &3» # Diese Zeile ist nicht editierbar!");
			getConfig().set("Scoreboard.4", "&e ");
			getConfig().set("Scoreboard.5", "&7Online:");
			getConfig().set("Scoreboard.6", " &8» # Diese Zeile ist nicht editierbar!");
			getConfig().set("Scoreboard.7", "&1 ");
			getConfig().set("Scoreboard.8", "&7Name:");
			getConfig().set("Scoreboard.9", " §8» &e%player%");
			getConfig().set("Scoreboard.10", "&1");
			getConfig().set("Scoreboard.11", "&7Teamspeak:");
			getConfig().set("Scoreboard.12", " §8» &eDeinServer.de");
			getConfig().set("Scoreboard.13", "&3");
			getConfig().set("Scoreboard.14", "&7Forum:");
			getConfig().set("Scoreboard.15", " &8» &ehttp://veromc.ml");
			getConfig().set("Scoreboard.16", "&4");
			getConfig().set("Chat.1", "&4Owner &8| &4%player% &7» %msg%");
			getConfig().set("Chat.2", "&4Admin &8| &4%player% &7» %msg%");
			getConfig().set("Chat.3", "&bDeveloper &8| &b%player% &7» %msg%");
			getConfig().set("Chat.4", "&cSrModerator &8| &c%player% &7» %msg%");
			getConfig().set("Chat.5", "&cModerator &8| &c%player% &7» %msg%");
			getConfig().set("Chat.6", "&9Supporter &8| &9%player% &7» %msg%");
			getConfig().set("Chat.7", "&eBuilder &8| &e%player% &7» %msg%");
			getConfig().set("Chat.8", "&5YouTuber &8| &5%player% &7» %msg%");
			getConfig().set("Chat.9", "&eHero &8| &e%player% &7» %msg%");
			getConfig().set("Chat.10", "&9Diamond &8| &9%player% &7» %msg%");
			getConfig().set("Chat.11", "&6Gold &8| &6%player% &7» %msg%");
			getConfig().set("Chat.12", "&8Spieler &8| &8%player% &7» %msg%");
			getConfig().set("Chat.Permission1", "skypvp.owner");
			getConfig().set("Chat.Permission2", "skypvp.admin");
			getConfig().set("Chat.Permission3", "skypvp.dev");
			getConfig().set("Chat.Permission4", "skypvp.srmod");
			getConfig().set("Chat.Permission5", "skypvp.mod");
			getConfig().set("Chat.Permission6", "skypvp.sup");
			getConfig().set("Chat.Permission7", "skypvp.builder");
			getConfig().set("Chat.Permission8", "skypvp.yter");
			getConfig().set("Chat.Permission9", "skypvp.hero");
			getConfig().set("Chat.Permission10", "skypvp.diamond");
			getConfig().set("Chat.Permission11", "skypvp.gold");
			getConfig().set("Chat.Permission12", "# Spieler brauchen keine Permission!");
			getConfig().set("Tab.1", "&4Owner &8| &4");
			getConfig().set("Tab.2", "&Admin &8| &4");
			getConfig().set("Tab.3", "&bDev &8| &b");
			getConfig().set("Tab.4", "&cSrMod &8| &c");
			getConfig().set("Tab.5", "&cMod &8| &c");
			getConfig().set("Tab.6", "&9Sup &8| &9");
			getConfig().set("Tab.7", "&eBuilder &8| &e");
			getConfig().set("Tab.8", "&5YTer &8| &5");
			getConfig().set("Tab.9", "&eHero &8| &e");
			getConfig().set("Tab.10", "&9Diamond &8| &9");
			getConfig().set("Tab.11", "&6Gold &8| &6");
			getConfig().set("Tab.12", "&8Spieler &8| &8");
			getConfig().set("Tab.Permission1", "skypvp.owner");
			getConfig().set("Tab.Permission2", "skypvp.admin");
			getConfig().set("Tab.Permission3", "skypvp.dev");
			getConfig().set("Tab.Permission4", "skypvp.srmod");
			getConfig().set("Tab.Permission5", "skypvp.mod");
			getConfig().set("Tab.Permission6", "skypvp.sup");
			getConfig().set("Tab.Permission7", "skypvp.builder");
			getConfig().set("Tab.Permission8", "skypvp.yter");
			getConfig().set("Tab.Permission9", "skypvp.hero");
			getConfig().set("Tab.Permission10", "skypvp.diamond");
			getConfig().set("Tab.Permission11", "skypvp.gold");
			getConfig().set("Tab.Permission12", "skypvp.spieler");
			getConfig().set("Build.On", "&aDer &eBau-Modus &awurde erfolgreich aktiviert!");
			getConfig().set("Build.Off", "&aDer &eBau-Modus &awurde erfolgreich deaktiviert!");
			getConfig().set("Build.Syntax", "&cSyntax: /build [an/aus]");
			getConfig().set("ChatClear", "&aDer Chat wurde von &e%player% &agecleart!");
			getConfig().set("Clear", "&aDu hast dein §eInventar &aerfolgreich gecleart!");
			getConfig().set("Umfrage.1", "&aEine neue Umfrage hat begonnen!");
			getConfig().set("Umfrage.2", "&aDie Frage lautet&8: &e%umfrage%");
			getConfig().set("Umfrage.3", "&aGebe eine Stimme ab mit /umfrage.");
			getConfig().set("Umfrage.Syntax", "&cSyntax: /createumfrage [Frage]");
			getConfig().set("Umfrage.Already", "Derzeit läuft bereits eine Umfrage!");

			
				cfg.save(path);
				
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		      saveConfig();
		      reloadConfig();
		}
		ConnectMySQL();
		}
	

	 

	public void onDisable() {
		Bukkit.getConsoleSender().sendMessage("######################");
		Bukkit.getConsoleSender().sendMessage("SkyPvP System");
		Bukkit.getConsoleSender().sendMessage("by ScienceCode[DE]");
		Bukkit.getConsoleSender().sendMessage("Version: " + getDescription().getVersion());
		Bukkit.getConsoleSender().sendMessage("######################");

		mysql.close();
		Bukkit.getConsoleSender().sendMessage("Die Verbindung zum MySQL wurde geschlossen!");
	}

	public static Main getInstance() {
		return instance;
	}

	public void ConnectMySQL() {
		String ip = getConfig().getString("MySQL.ip");
		String database = getConfig().getString("MySQL.database");
		String name = getConfig().getString("MySQL.name");
		String passwort = getConfig().getString("MySQL.password");
		try {
			mysql = new MySQL(ip, database, name, passwort);
			mysql.update(
					"CREATE TABLE IF NOT EXISTS StatsAPI(UUID varchar(64), KILLS int, DEATHS int, PLAY int, WINS int);");
			Bukkit.getConsoleSender().sendMessage("§aDie MySQL Verbindung war erfolgreich!");

		}

		catch (Exception error) {
			Bukkit.getConsoleSender().sendMessage("§aDie MySQL Verbindung konnte nicht hergestellt werden!");
			Bukkit.getPluginManager().disablePlugin(this);

		}
	}
	

	@SuppressWarnings("deprecation")
	@EventHandler
	public void onLogin(AsyncPlayerPreLoginEvent event) {
		if (wartung) {
			
			
			for (OfflinePlayer op : Bukkit.getWhitelistedPlayers()) {
				if (op.getName().equalsIgnoreCase(event.getName())) {
					return;
				}
			}

			if (!Bukkit.getOfflinePlayer(event.getName()).isOp()) {
					event.disallow(Result.KICK_OTHER, "§cDu darfst den Serer nicht betreten! \n\n §eGrund: §4Wartungen");

				
			}
		}
	}

	@EventHandler
	public void onPing(ServerListPingEvent event) {
		if (wartung) {
			event.setMaxPlayers(0);
			event.setMotd("§8[§4!§8] §4✘ §eDein SkyPvP Server §4✖ §c§lWartungsarbeiten §4✖");
		}
	}

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

		if (command.getName().equalsIgnoreCase("wartung")) {
			if (sender.hasPermission("skypvp.wartung") || sender.isOp()) {

				if (args.length == 0) {
					sender.sendMessage(getConfig().getString("Prefix") + "§cSyntax: /wartung [an/aus]");
				}

				if (args.length == 1) {

					if (args[0].equalsIgnoreCase("an")) {
						wartung = true;
						sender.sendMessage(getConfig().getString("Prefix") + "§aDu hast den §eWartungs-Modus §aaktiviert!");
					}

					if (args[0].equalsIgnoreCase("aus")) {
						wartung = false;
						sender.sendMessage(getConfig().getString("Prefix") + "§aDu hast den §eWartungs-Modus §adeaktiviert!");
					}

					getConfig().set("Wartung.Status", wartung);
					saveConfig();

					return true;
					
				}

				return false;
			}
			return false;
		}

		return false;
	}
	
	/*
	 * Hey Leute.
	 * Heute möchte ich euch mein SkyPvP Plugin vorstellen.
	 * Es hat lange gedauert, jedoch hat es mir auch Spaß gemacht. ^.^
	 * Mitlerweile ist das Plugin schon auf Spigot veröffentlicht.
	 * Dies waren erstmal die wichtigsten Funktionen.
	 * Für sonstige Anfragen: http://veromc.ml/contact.html
	 * Download: https://spigotmc.org/resources/skypvp-system-1-8-8-beta.56277/
	 * Nun wünsche ich euch noch sehr viel Spaß mit dem Plugin <3
	 * Hier nochmal die Packets/Classes..
	 * Nun verabschiede ich mich von euch und wünsche Ihnen noch einen wunderschönen Vormittag/Nachmittag... c:
	 */

}
